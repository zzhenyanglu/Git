/*********************************************
/*  MPCS 52011 - Intro to Computer System 
/*  Project 10: Compiler - part I
/*  Author: Zhenyang Lu
/*********************************************

/*******************************************************
/*  PART A: Brief introduction to sourcecode and project
/*******************************************************  

# NOTICE: 
 
when you compare XMLs, you will see many occasions like the following: 
          -     <parameterList></parameterList>
          +     <parameterList />

          AND

          -     <expressionList></expressionList>
          +     <expressionList />


this is not showing a content difference, rather it's different way of showing empty XML tree. 
the python library I use can not print XML tree with html way. I cound not figure out
a way to resolve this. essentially, these two lines both means empty element. 




0. Structure of the source code: 
  0). functions
    a. StripComments(file_path_in='', file_path_out='')
      FUNCTIONALITY: clean up the comments and whitespaces
      ARGUMENTS: 
        file_path_in: address of the input file, which is passed in by the main function
                      and is the file we want to parse white spaces out.  
        file_path_out: the address to output the parsed file, instead of .out, it output a .parsed file. 
      output: create a .parsed file in the XML subdirectory of the input direcory.  

    b. tokenizer(file_path_in='', file_path_out='')
      FUNCTIONALITY: Reads in a .parsed file, tokenize the file and output a "xxxT.xml" file, which can be used
                     to be compared with benchmark xxxT.xml files
      ARGUMENTS: 
        file_path_in: address of the input .parsed file, which is passed in by the main function
                      and is the file we want to tokenize. 
        file_path_out: the address to output "xxxT.xml" file.
 
      output: create a "xxxT.xml" file in the XML subdirectory of the input direcory. 

    c. CompileEngine(file_path_in='', file_path_out='')
      FUNCTIONALITY: Reads in a "xxxT.xml" file, Kick off the CompileCalss() function, create a token_list
                     which contains all the tokens from raw file and create a "xxx.xml", which is the final files we 
                     need to compare with benchmarks.
      ARGUMENTS: 
        file_path_in: address of the input "xxxT.xml" file, which is passed in by the main function
                       
        file_path_out: the address to output "xxx.xml" file.
 
      output: create a "xxx.xml" file in the XML subdirectory of the input direcory.

    d. OTHER FUNCTIONS:
      CompileClass(parent_element, start_pos)
      CompileSubroutineBody(parent_element,start_pos)
      CompileSubroutineDec(parent_element, start_pos)
      CompileStatement(parent_element,start_pos)
      CompileReturn(parent_element,start_pos)
      CompileWhile(parent_element,start_pos)
      CompileIF(parent_element,start_pos)
      CompileLet(parent_element,start_pos)
      CompileExpression(parent_element,start_pos)
      CompileExpressionList(parent_element,start_pos)
      CompileTerm(parent_element,start_pos)
      CompileDo(parent_element,start_pos)
      CompileSubroutineCall(parent_element,start_pos)
      CompileVarDec(parent_element, start_pos)
      CompileParameterList(parent_element, start_pos)                        
      CompileClassVarDec(parent_element, start_pos)
    
      FUNCTIONALITY: when called, parses a piece of XML tokens. 
      ARGUMENTS: 
        parent_element: specify the parent XML tree the output XML belongs to
                       
        start_pos: signals the function should starts from which token of the program's token list
 
      output: create a piece of XML tree, which the final XML structure consists of.           

   1). Main function to control the whole program and parse the input directory/file path, and pass the right 
       paths as arguments to CompileEngine() 
 

1. User interface:
  0). THIS program has two parameters: 
    a. dir_path: it can be a directory path(relative/absolute) or a file path(relative/absolute).
    b. bootstrap: it only becomes effective when you want to translate a FOLDER, AKA, when the first
                  parameter you specify is a directory. When you specify True, the program will initiate
                  bootstrap process before creating .asm files 

  1). LINUX:
    To execute the source code, you could use the following command line: 
    (Assuming you are currently in the folder which contains the source code)
      $ python Translator.py file_path True/False 
    
    more examples of Linux command lines to invoke the source code will be provided later. 
    file_path and nocomments respectively corresponse to the two arguments of the function introduced on section 0 

  2). WINDOWS:
    Please go to LINE 261 and change the parameters 
 

2. Portability:
  The code is written on windows Python 2.7 and has been tested against Linux on linux.uchicago.edu server. 
  Hopefully it's working fine on all OS. 

/*********************************************
/*  PART B: COMPILE AND RUN THE SOURCE CODE 
/********************************************* 

  0. How to COMPILE/RUN the source code on LINUX: 
 
     PLEASE NOTE:   
     a. I provide two versions of programs, one called Parser.py for linux, another called Translator_windows.py is 
        for windows. The only difference is how to kick it off. In linux, you could use command line parameter to speficy 
        directory, in windows you have to put it to the code yourself (LINE 800).
         
  1. To compile and run the source code you could use the any of the following commands ON LINUX: 
  
     $ python Parser.py ./         # RELATIVE DIRECTORY PATH, which is the folder contains the raw .jack files 

     $ python Parser.py ~/your_server_user_name_here/ArrayTest    # ABSOLUTE PATH, which is the folder contains the raw .jack files

     # python Parser.py ~/your_server_user_name_here/ArrayTest/Main.jack


  2. How to COMPILE/RUN the source code on Windows: 
     please go to Parser_windows.py and change dir_path on line 800 to the file you want to parse   

  3. Interpret the results: 
     check out "xxxT.xml" and "xxx.xml" files in XML subdirectory you specify as argument. 
   
