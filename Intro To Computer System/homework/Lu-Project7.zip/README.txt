/*********************************************
/*  MPCS 52011 - Intro to Computer System 
/*  Project 7: VM Translator
/*  Author: Zhenyang Lu
/*********************************************

/*******************************************************
/*  PART A: Brief introduction to sourcecode and project
/*******************************************************  

0. Structure of the source code: 
  0. fucntions
    a. StripComments(file_path='', file_path_out='')
      FUNCTIONALITY: clean up the comments and whitespaces
      ARGUMENTS: 
        file_path: address of the input file, either relative or absolute,
                   which is the file we want to parse white spaces out.  
        file_path_out: the address to output the parsed file, instead of .out, it output a .parsed file. 
      output: create a .parsed file to the directory of the input file.  

    b. push(file_name='',mtype, index)
      FUNCTIONALITY: translate a piece of .asm code according to type of memory to which it pushes.  
      ARGUMENTS: 
        file_name: name of the input file, which is used to differentiate each other, if we have many pushes within a single .VM file. 
        mtype: memory type to which we pushes('constant','pointer' .....). 
        index: argument of push.
      OUTPUT: return a line of .asm code to perform push.

    b. pop(file_name='',mtype, index)
      FUNCTIONALITY: translate a piece of .asm code according to type of memory to which it pop.  
      ARGUMENTS: 
        file_name: name of the input file, which is used to differentiate each other, if we have many pops within a single .VM file. 
        mtype: memory type to which we pops('constant','pointer' .....). 
        index: argument of pop.
      OUTPUT: return a line of .asm code to perform pop.

    d. arithmetic(command='',counter=0)
      FUNCTIONALITY: translate a piece of .asm code to perform a arithmetic command
      ARGUMENTS: 
        command: add, neg, not.... but default it's constant. 
        counter: a counter to differetiate loops inside eq, lt, gt. 
      OUTPUT: return a line of .asm code to perform logic arithmetics.

    c. hack_code_generator(file_path='',file_path_out='')
      FUNCTIONALITY: takes in the .parsed file and output a .asm file to the directory specified by file_path_out.  
      ARGUMENTS: 
        file_path: address of the input file, .parse, from StripComments function(the file you specify with file_path_out parameter). 
        file_path_out: directory of the .asm file.
      OUTPUT: output a .asm file.

   1. Main function to control the whole program. 


1. User interface:
  LINUX:
    To execute the source code, you could use the following command line: 
    (Assuming you are currently in the folder which contains the source code)
      $ python Translator.py file_path True/False 
    
    more examples of Linux command lines to invoke the source code will be provided later. 
    file_path and nocomments respectively corresponse to the two arguments of the function introduced on section 0 

2. Portability:
  The code is written on windows Python 2.7 and has been tested against Linux on linux.uchicago.edu server. 
  Hopefully it's working fine on all OS. 

/*********************************************
/*  PART B: COMPILE AND RUN THE SOURCE CODE 
/********************************************* 

  0. How to COMPILE/RUN the source code on LINUX: 
 
     PLEASE NOTE:   
     a. I provide two versions of assembler.py one called Assembler.py is for linux, another called Assembler_windows.py is 
        for windows. The only difference is how to kick it off. In linux, you could use command line parameter to speficy 
        directory, in windows you have to put it to the code yourself.
         

  1. To compile and run the source code you could use the any of the following commands ON LINUX: 
  
     $ python Translator.py BasicTest.vm    # RELATIVE PATH and no comments
  
     $ python Translator.py BasicTest.vm    /home/your_server_user_name_here/BasicTest.vm     # ABSOLUTE PATH and keep comments  

  2. How to COMPILE/RUN the source code on Windows: 

     please go to Translator_windows.py and change file_path on line 177 to the file you want to translate you good to go   

  3. How to COMPILE/RUN the source code on WINDOWS:
     To run it on windows OS, you should open the sourcecode file with Python IDLE, then run it. 
     You will be prompted to enter file path. Do it as instructed. 

  3. Interpret the results: 
     check out your .asm file in the directory of your .vm file 
   
