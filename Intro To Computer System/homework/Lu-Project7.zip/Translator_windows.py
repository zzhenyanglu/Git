import os.path
import sys
from sys import platform

##########################################################################

# Begin - Functions Definition

##########################################################################

# in case we handle multiple files in a folder, change the StripComments functions
# so that it reads in all the files and output only one .asm file

def StripComments(file_path='', file_path_out = ''):

    # Read the input file
    infile=open(file_path,'r')

    # Write the output file if the program is permitted to do so
    if os.path.isfile(file_path_out):
        os.remove(file_path_out)
    outfile=open(file_path_out,'a')

    for i in infile.readlines():

        line =i.strip()

        # if blank line or comments, skip it
        if line =='' or line[0:2] =='//':
            continue
            
        # otherwise, continue to process spaces and tabs
        else:
           line_len = len(line)
           for i in range(line_len-1):
               if line[i:min(line_len,i+2)] =='//':
                   line = line[0:i]
                   break
           line=line+'\n'
           outfile.write(line)
            
    infile.close()
    outfile.close()

#mtype is 'constant','pointer' .....
def push(file_name, mtype, index ):
    if mtype == 'constant':
        return "@" + index + "\nD=A\n@SP\nA=M\nM=D\n@SP\nM=M+1\n"
    
    elif mtype == 'local': 
        return "@LCL\nD=M\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'this':
        return "@THIS\nD=M\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'that':
        return "@THAT\nD=M\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'pointer':
        return "@3\nD=A\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'argument':
        return "@ARG\nD=M\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'temp':
        return "@5\nD=A\n@" + index + "\nA=D+A\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    elif mtype == 'static':
        return "@" + file_name + "." + index + "\nD=M\n@SP\nM=M+1\nA=M-1\nM=D\n"
    
    else : return 0

def pop(file_name, mtype , index):
    if mtype == 'local': 
        return "@LCL\nD=M\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"
    
    elif mtype == 'this':
        return "@THIS\nD=M\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"
    
    elif mtype == 'that':
        return "@THAT\nD=M\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"
    
    elif mtype == 'pointer':
        return "@3\nD=A\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"
    
    elif mtype == 'argument':
        return "@ARG\nD=M\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"
    
    elif mtype == 'temp':
        return "@5\nD=A\n@" + index + "\nD=D+A\n@R13\nM=D\n@SP\nM=M-1\nA=M\nD=M\n@R13\nA=M\nM=D\n"

    elif mtype == 'static':
        return "@SP\nM=M-1\nA=M\nD=M\n@" + file_name + "." + index + "\nM=D\n"
    else : return 0


def arithmetic(command='', counter=0):
    if command == 'add': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nMD=D+M\n"
    elif command == 'neg': return "@SP\nA=M-1\nM=-M\n"
    elif command == 'not': return "@SP\nA=M-1\nM=!M\n"
    elif command == 'lt':  return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nD=D-M\n@if_true_" + str(counter) + \
                                  "\nD;JGT\n@SP\nA=M-1\nM=0\n@END_" + str(counter) + "\n0;JMP\n(if_true_" \
                                   +str(counter) + ")\n@SP\nA=M-1\nM=-1\n(END_" + str(counter)+")\n"
    elif command == 'eq': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nD=D-M\n@if_true_" + str(counter) + \
                                 "\nD;JEQ\n@SP\nA=M-1\nM=0\n@END_" + str(counter) + "\n0;JMP\n(if_true_" +str(counter) + \
                                 ")\n@SP\nA=M-1\nM=-1\n(END_" + str(counter)+")\n"
    elif command == 'gt': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nD=D-M\n@if_true_" + str(counter) +\
                                 "\nD;JLT\n@SP\nA=M-1\nM=0\n@END_"+ str(counter) + "\n0;JMP\n(if_true_"\
                                  +str(counter) + ")\n@SP\nA=M-1\nM=-1\n(END_" + str(counter)+")\n"
    elif command == 'or': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nM=D|M\n"
    elif command == 'and': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nM=D&M\n"
    elif command == 'sub': return "@SP\nAM=M-1\nD=M\n@SP\nA=M-1\nMD=M-D\n"
    else : return 0

    
def hack_code_generator(file_path='', file_path_out=''):
    
    # Read the input file
    infile=open(file_path,'r')

    # get name of the file, which is used for pop/push static
    # e.g @xxx.3, xxx is file_name
    file_name = os.path.basename(file_path).split('.')[0]

    # Write the output file if the program is permitted to do so
    if os.path.isfile(file_path_out):
        os.remove(file_path_out)
        
    outfile=open(file_path_out,'a')

    # counter is to counting how many 'lt', 'eq' and 'gt' we encoutner
    # so that the jumps inside them are not interfering with each other.    
    counter = 0

    for i in infile.readlines():

        i = i.lower().strip('\n')

        # if the current line is push
        if (i.find('push') != -1):
            a, b, c = i.split(' ')
            outfile.write(push(mtype = b, file_name =file_name, index = c))

        # if the current line is push           
        if (i.find('pop') != -1):
            a, b, c = i.split(' ')
            outfile.write(pop(mtype = b, file_name =file_name, index = c))

        # if the current line is arithmetic operation(+-!&..) 
        elif len(i) < 7:
            if i in ('lt', 'gt', 'eq'): counter = counter + 1
            outfile.write(arithmetic(command = i, counter = counter))

        # if the current line is goto
        

    infile.close()
    outfile.close()


##########################################################################

# End - Functions Definition

##########################################################################



##########################################################################

# Begin - main function

##########################################################################

# let's run our ASSEMBLER!

file_path = "C:\Users\zheny\Dropbox\courses\Intro to computer system (52011)\\nand2tetris\\projects\\07\MemoryAccess\PointerTest\PointerTest.vm"


#file_path=sys.argv[1]

# extract directory of the specified file_path
file_dir = os.path.dirname(file_path)

# if it is relative path get the current working directory
if file_dir == '':
    file_dir = os.getcwd()
    file_path = os.path.join(file_dir,file_path)

# store input file name, file directory and absolute file path and 
# create and store output file name and file path
file_name = os.path.basename(file_path)
file_name_out = file_name.split('.')[0] +'.parsed'
asm_file_name = file_name.split('.')[0] +'.asm'
file_path_out = os.path.join(file_dir,file_name_out)  
file_path_asm = os.path.join(file_dir,asm_file_name)  

# if file directory or the file itself does not exist
# tell the user it is wrong and stop the function
# otherwise continue
    
if os.path.exists(file_dir):
    if os.path.isfile(file_path) == False:
        print "file " + file_name +" does not exist in "+ file_dir
    else:
        print "file "+file_name+" found in "+ file_dir+ "\n...continue"
        StripComments(file_path=file_path,  file_path_out=file_path_out)
        hack_code_generator(file_path=file_path_out, file_path_out = file_path_asm)
else:
    print "directory "+file_dir+" does not exist!"



##########################################################################

# End - main function

##########################################################################
