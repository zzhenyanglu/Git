#!/usr/bin/env python3
"""
Code for HW2, problem 6

Usage: prob6.py [n [nsim [decimal_precision]]]
"""

import sys
import random
import itertools

import numpy as np

import mpmath
from mpmath import mp, mpf


# NOHITS[i] contains the number of zero hit permutations of size i.
# NOHITS[0] is unused.
NOHITS = [mpf(0)] * 1000
NOHITS[2] = mpf(1)

# Track how far we've already calculated.
NEXT_NOHITS = 3


# can be overridden by 3rd arg. Number of decimal places.
mp.dps = 68


def randperm(n):
    """
    Return random permutation of first n positive integers as a python list.
    """
    a = list(range(1, n + 1))
    for i in range(n-1, 0, -1):
        swapi = random.randint(0, i)
        tmp = a[i]
        a[i] = a[swapi]
        a[swapi] = tmp
    return a


def count_hits(perm):
    """
    Return number of hits in a permutation.

    @param perm: python list containing integers 1-n, where n is the length of
                 the list
    """
    hits = 0
    for i in range(len(perm)):
        if perm[i] == i+1:
            hits += 1
    return hits


def num_zero_hits(n):
    """
    Use recurrence relation to calculate number of zero hit permutations
    of length n:

        N_n = (n-1) (N_{n-1} + N_{n-2}).

    """
    global NEXT_NOHITS
    for i in range(NEXT_NOHITS, n+1):
        NOHITS[i] = (i-1) * (NOHITS[i-1] + NOHITS[i-2])
    NEXT_NOHITS = n + 1
    return NOHITS[n]


def test_num_zero_hits(maxn):
    """
    Generate all permulations and count how many have zero hits, and
    compare with the value calculated by the recurrence relation in
    num_zero_hits.

    Warning: order n!, generates all possible permutations
    """
    print("==== n, # no hit permutations ====")
    nohits_list = []
    for n in range(2, maxn+1):
        nohits = 0
        for p in itertools.permutations(range(1,n+1)):
            if count_hits(p) == 0:
                nohits += 1
        if len(nohits_list) > 1:
            assert(nohits == (n-1) * (nohits_list[-1] + nohits_list[-2]))
        print(n, nohits, num_zero_hits(n))


def ev_var(n):
    """
    Use probability theory and recurrence relation for number of zero hits
    to calculate expected value and variance for X_n := number of hits in
    a permutation of length n.

    This version calculates the numerator first, and divides through by the
    common denominator n! at the end.

    Requires two size n loops, one to calculate the no hit counts using the
    recurrence relation, and another to calculate expected value and
    variance.

    There is a simple analytic exact solution for expected value, so
    calculating it here is not strictly necessary, but it provides
    verification for the validity of the method.
    """
    total_ev = mpf(0)
    total_var = mpf(0)
    denom = mpmath.factorial(n)
    n_nohit = [mpf(0)] * (n+1)
    n_nohit[2] = mpf(1)
    for i in range(3, n):
        n_nohit[i] = (i-1) * (n_nohit[i-1] + n_nohit[i-2])
    total = 0
    # having n-1 hits is not possible
    for i in range(1, n-1):
        count = mpmath.binomial(n, i) * n_nohit[n-i]
        total_ev += i * count
        total_var += i**2 * count
    # special case n hits
    total_ev += mpf(n) * 1
    total_ev /= denom
    total_var += (mpf(n) - total_ev)**2 * 1
    total_var /= denom
    total_var -= total_ev**2
    return (total_ev, total_var)


def ev_var2(n):
    """
    Alternate version of ev_var that divides through by n! at each loop
    iteration. Because of cancellation, this gets rid of the binomial and
    moves factorials to the denominator.

    Does not appear to make significant difference.
    """
    total_ev = mpf(0)
    total_var = mpf(0)
    n_nohit = [mpf(0)] * (n+1) # NOTE: one based array, 0th is not used
    n_nohit[2] = mpf(1)
    for i in range(3, n):
        n_nohit[i] = (i-1) * (n_nohit[i-1] + n_nohit[i-2])
    total = 0
    # having n-1 hits is not possible
    for i in range(1, n-1):
        p = n_nohit[n-i] / mpmath.factorial(i) / mpmath.factorial(n - i)
        total_ev += i * p
        total_var += i**2 * p
    # special case n hits
    total_ev += 1 / mpmath.factorial(n-1)
    total_var += (mpf(n) - total_ev)**2 / mpmath.factorial(n)
    total_var -= total_ev**2
    return (total_ev, total_var)


def simulate_ev_var(n, nsim):
    """
    Generate nsim random permutations of size n, and compute the expected
    value and variance of the sample.

    Returns (expected_value, variance)
    """
    hits = np.empty(nsim, np.int8)
    for i in range(nsim):
        perm = randperm(n)
        hits[i] = count_hits(perm)
    return (np.mean(hits), np.var(hits))


def main():
    if len(sys.argv) > 1:
        n = int(sys.argv[1])
    else:
        n = 50

    if len(sys.argv) > 2:
        nsim = int(sys.argv[2])
    else:
        nsim = 100000

    if len(sys.argv) > 3:
        mp.dps = int(sys.argv[3])

    stats1 = ev_var(n)
    #stats2 = ev_var2(n)
    print("EV  =", str(stats1[0]))
    print("VAR =", str(stats1[1]))
    #print("EV  =", str(stats2[0]))
    #print("VAR =", str(stats2[1]))

    print("\n==== simulation for n=%d, nsim=%d ====" % (n, nsim))
    sim_ev_var = simulate_ev_var(n, nsim)
    print("mean:", sim_ev_var[0])
    print("var :", sim_ev_var[1])


if __name__ == '__main__':
    #test_num_zero_hits(int(sys.argv[1]))
    main()
