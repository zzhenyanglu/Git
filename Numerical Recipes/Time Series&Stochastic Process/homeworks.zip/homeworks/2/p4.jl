#!/usr/bin/env julia
#=

Example usage:

    julia p4.jl 1000000

Simulation to estimate P{X < Y} from joint PDF f(x, y) = 2e^(-x-2y). Note
that X and Y are independent so we can sample from f_x(x) = e^(-x) and
f_y(y) = 2e^(-2y) to and compare for the simulation.
=#


# Sample from PDF f_x(x) using inverse method.
function sample_x()
    U = rand(Float64)
    return -log(1 - U)
end

# Sample from PDF f_y(y) using inverse method.
function sample_y()
    U = rand(Float64)
    return log(1 - U) / -2.0
end


function simulate_x_lt_y(nsim)
    hits = 0
    for i = 1:nsim
        x = sample_x()
        y = sample_y()
        if x < y
            hits += 1
        end
    end
    return hits / nsim
end


function usage()
    println("Usage: julia $PROGRAM_FILE nsim")
end


if length(ARGS) != 1
    usage()
    exit(1)
end
nsim = tryparse(Int64, ARGS[1])
if isnull(nsim)
    usage()
    exit(1)
else
    # remove nullable
    nsim = get(nsim)
end
println(simulate_x_lt_y(nsim))
