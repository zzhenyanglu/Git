#!/usr/bin/env python3
"""
Problem 2.1 from Shumway 3rd ed, p78. Displays graph with original data as
points, and model data as line, and graph with residuals.

Answers to written portion of question:

(b) Adding an intercept term introduces linear dependence between columns
    of Z - the column of all 1's is the sum of the quarter indicator columns.
    This makes Z'Z singular. Depending on how the solver is implemented, it
    may still return a solution, but the system is underdetermined (also called
    rank deficient) and there are multiple solutions that minimize the least
    squares. Adding an intercept term is not useful.

(c) The mean of the residuals is small, and the variance is reasonable, but
    looking at a plot, they don't seem completely uncorrelated. The model
    seems to have accouted for some of the variation, but not all.
"""

import numpy as np

import matplotlib.pyplot as plt


def read_jj_series(path):
    data = []
    with open(path) as f:
        for line in f:
            data.append(float(line.strip()))
    return data


def get_matrix(npoints, start_year=0, intercept=False):
    """
    Return matrix with rows containing (year, Q1, Q2, Q3, Q4), where
    year goes up in quarter increments, and only the corresponding Q is
    1 (the others are zero).

    If @intercept is True, add a 6th column at the end with all 1s.
    """
    if intercept:
        cols = 6
    else:
        cols = 5
    assert npoints % 4 == 0
    y = start_year
    q = 0
    M = np.zeros((npoints, cols), dtype=np.float64)
    for i in range(npoints):
        M[i,0] = y
        M[i,q+1] = 1
        q = (q + 1) % 4
        y += 0.25
        if intercept:
            M[i,5] = 1
    return M


def regression(x, intercept=False):
    Z = get_matrix(x.shape[0], 0, intercept)
    Zt = Z.transpose()
    M = Zt.dot(Z)

    if np.linalg.matrix_rank(M) < M.shape[0]:
        # the latest version of np.linalg.solve does not raise an
        # exception in this case, so check for it ourselves.
        raise ValueError("system is under determined")
    b = Zt.dot(x)
    return Z, np.linalg.solve(M, b)


if __name__ == '__main__':
    y = read_jj_series("jj_series.txt")
    print("jj      mean:", np.mean(y), ", var:", np.var(y))
    x = np.log(y)
    print("log(jj) mean:", np.mean(x), ", var:", np.var(x))

    Z, betas_a = regression(x, False)
    print("linear fit (no intercept)", betas_a)
    xa = Z.dot(betas_a)
    ts = Z[:,0]
    resid = x - xa
    SSE = np.sum(resid**2)

    try:
        Z_i, betas_b = regression(x, True)
    except ValueError as e:
        print("Error doing regression with intercept:", e)
    else:
        assert False, "Expected regression error with intercept, got none"

    print("residual no intercept (mean, var)",
          np.mean(resid), np.var(resid), "SSE", SSE)

    # plot data as points, model as line
    plt.figure()
    plt.plot(ts, x, marker='.', linestyle='')
    plt.plot(ts, xa)

    # plot residuals
    plt.figure()
    plt.plot(ts, resid)

    # show both figures
    plt.show()
