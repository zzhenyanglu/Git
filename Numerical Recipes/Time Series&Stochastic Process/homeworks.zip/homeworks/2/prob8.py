#!/usr/bin/env python3
"""
See solution PDF for analysis of using h(x) = a tan(x) with rejection method
(implemented here in rand_tan).
"""

import random
import math
import time

import numpy as np

def rand_2x():
    """
    Use rejection method with h(x) = 2x on (0, 1) to generate numbers for
    PDF f(x) = 3x^2, with c = 3/2.
    The CDF for h is H(x) = x^2, so we can generate from distribution
    h using square root.

    Returns (random_value, num_iters)
    """
    i = 1
    while True:
        y = math.sqrt(random.random())
        U = random.random()
        if U < y:
            return (y, i)
        i += 1


def rand_1():
    """
    Use rejection method with g(x) = 1 on (0, 1) to generate numbers for
    PDF f(x) = 3x^2, with c = 3.
    The CDF for g is G(x) = x, which is just standard uniform distribution.

    Returns (random_value, num_iters)
    """
    i = 1
    while True:
        y = random.random()
        U = random.random()
        if U < y**2:
            return (y, i)
        i += 1


m = 1.0 / math.log(1.0/math.cos(1))
def rand_tan():
    """
    Use h(x) = 1/ln(sec(1)) tan(x) as PDF for rejection method. See pdf
    for analysis. The value of c = 1.2 was selected by eyeballing graphs.
    """
    i = 1
    while True:
        y = math.acos(1 / math.exp(random.random() / m))
        U = random.random()
        if U < (3 * y**2 / (1.2 * m * math.tan(y))):
            return (y, i)
        i += 1


def rand_inv():
    """
    Use analytic inverse of antiderivative to generate random numbers from
    PDF f(x) = 3 x^2. F(X) = x^3, F^{-1}(X) = x^{1/3}.
    """
    return (math.pow(random.random(), 1/3.0), 1)


def test_rand_fn(fn, nsim=100000):
    xs = np.empty(nsim, dtype=np.float)
    times = np.empty(nsim, dtype=np.float)
    iters = np.empty(nsim, dtype=np.int32)
    for i in range(nsim):
        start = time.time()
        xs[i], iters[i] = fn()
        times[i] = time.time() - start
    sample_mean = np.mean(xs)
    sample_var = np.var(xs)
    print("mean", sample_mean)
    print("var ", sample_var)
    print("iters  ", np.mean(iters), np.var(iters))
    print("seconds", np.mean(times), np.var(times))


def test_all():
    print("==== expected ====")
    print("mean", 0.75)
    print("var ", 0.0375)
    for fn_name in "rand_1 rand_2x rand_tan rand_inv".split():
        print("====", fn_name, "====")
        fn = globals()[fn_name]
        test_rand_fn(fn)


if __name__ == '__main__':
    test_all()
