#!/usr/bin/env python3
"""
HW2 problem 7

Usage:

 prob7.py [nsim]

Prints estimate of probability that sum of claims > 50,000

Answer is ~ 0.107
"""
import sys
import random
import math


def random_binomial(n, p):
    """
    Generate random value with distribution binomial(n, p).
    See Ross 5th ed, p56.
    """
    if p > .5:
        # Takes 1 + np loops on average, so 1-p is faster if p > .5
        return n - random_binomial(n, 1 - p)
    U = random.random()
    c = p/(1-p)
    pr = (1-p)**n
    F = pr
    i = 0
    while U >= F:
        pr *= (c * (n - i) / (i + 1))
        F += pr
        i += 1
    return i


def test_random_binomial(n, p):
    import numpy as np
    nsim = 100000
    xs = np.empty(nsim, np.int32)
    for i in range(nsim):
        xs[i] = random_binomial(n, p)
    print("mean:", np.mean(xs), n * p)
    print("var :", np.var(xs), n * p * (1-p))


def simulate_month(policy_holders, p_claim, avg_claim):
    """
    Simulate a month of claims, assuming that the probability of a claim
    from each holder is p_claim and the amount of claims is an expontential
    random variable with mean avg_claim.
    """
    assert 0 < p_claim < 1
    n_claims = random_binomial(policy_holders, p_claim)
    claim_sum = 0
    for i in range(n_claims):
        # Generate exponential random variale with mean avg_claim and
        # add to total; see Ross Example 5b
        claim_sum -= math.log(random.random()) * avg_claim
    return claim_sum


def test():
    test_random_binomial(1000, .05)
    test_random_binomial(10, .5)
    test_random_binomial(7, .6)
    test_random_binomial(200, .001)


def main():
    # estimate probability that total monthly claims exceeds 50,000
    nsim = 10000
    if len(sys.argv) > 1:
        nsim = int(sys.argv[1])
    over_count = 0.0
    for i in range(nsim):
        if simulate_month(1000, 0.05, 800) > 50000:
            over_count += 1

    print(over_count / nsim)


if __name__ == "__main__":
    #test()
    main()
