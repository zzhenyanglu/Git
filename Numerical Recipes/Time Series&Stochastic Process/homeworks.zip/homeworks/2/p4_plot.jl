#!/usr/bin/env julia
#=
Plot the marginal CDFs of joint PDF f(x, y) = 2e^(-x-2y).
=#

using Gadfly

Fx(x) = 1 - exp(-x)
Fy(y) = 1 - exp(-2y)

p = plot([Fx, Fy], 0, 5,
 Guide.title("Marginal CDFs F_x and F_y for joint PDF f(x, y) = 2e^(-x-2y)"))
draw(SVGJS("p4.svg", 800px, 600px), p)
