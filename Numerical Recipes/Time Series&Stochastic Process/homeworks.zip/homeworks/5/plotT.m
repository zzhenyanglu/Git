function [ ] = plotT( x,T )

 axis([0 10 0 10]);
 plot(x,T);
 xlabel('Position on bar (x)');
 ylabel('Temperature (T)');
 set(gca,'YLim',[0,1]);
 pause(.01);
end

