function [ Tnew ] = singleStep( T,C )
%Apply Ax for the 1D FTCD discretization
%   Use built-in del2 rather than explicit loop
Tnew = T + C*del2(T);
end

