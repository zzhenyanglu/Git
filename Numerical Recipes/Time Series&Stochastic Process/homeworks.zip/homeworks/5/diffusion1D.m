%a script to solve the 1d heat equation using
%explicit timestepping and centered differencing

%plot settings
hold off;
axis manual;
axis([0 1 0 1]);

%input parameters
nx     = 1000;       % number of grid points
L      = 1;          % physical size of bar
nsteps = 20000;      % number of time steps
alpha  = .001;       % diffusivity
dt     =.0005;       % timestep  
lbval  = 0.;         % left and right boundary values
rbval  = 0.;
doplot = true;

%derived parameters
dx     = L/nx;       % grid spacing          
C = alpha*dt/dx^2;   % for convenience

%create initial condition
x=linspace(0,L,nx+2);     %in this case 1d Gaussian
T = exp(-(5*(x-0.5)).^2) + .2*randn(1,nx+2); 
Tnew = zeros(size(T));    %Tnew is solution 1 timestep in future

%set boundary conditions
T(1) = lbval; T(end) = rbval;  

%show initial condition
plotT(x,T);

tic;
for n=1:nsteps
    fprintf(1,'timestep: %d;  max: %f\n', n, max(T));
    Tnew = singleStep(T,C);
    if (doplot && ~mod(n,100))
     plotT(x,Tnew);
    end
    T = Tnew; T(1)=lbval; T(end)=rbval;
end
toc;
fprintf('mean(T): %f\n', mean(T));
