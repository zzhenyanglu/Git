#!/usr/bin/env Rscript

library("astsa")
rec = scan("data/rec_series.txt")

X11()

acf2(rec, 48)
message("Press Return To Continue")
invisible(readLines("stdin", n=1))

(regr = ar.ols(rec, order=2, demean=FALSE, intercept=TRUE))
regr$asy.se.coef

plot(rec)
message("Press Return To Continue")
invisible(readLines("stdin", n=1))
