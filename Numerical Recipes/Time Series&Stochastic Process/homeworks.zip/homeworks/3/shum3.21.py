#!/usr/bin/env python3
"""
Problem 3.21 p170.
"""

import sys

import numpy as np
import matplotlib.pyplot as plt

import common
import arma


def main():
    if len(sys.argv) > 1:
        nsim = int(sys.argv[1])
    else:
        nsim = 10
    n = 200
    phi = 0.9
    theta = 0.5
    print("actual  ", phi, theta, 1)

    for i in range(nsim):
        xt = arma.arma_generate(n, np.array([phi]), np.array([theta]))
        try:
            phi2, theta2, sigma2_w = arma.arma11_fit(xt)
        except np.linalg.LinAlgError as e:
            print("error", e)
            print("mean", np.mean(xt))
            print("var ", np.var(xt))
            plt.plot(xt, marker='.', linestyle='-')
            plt.show()
            break
        print("estimate", phi2, theta2, sigma2_w)


if __name__ == "__main__":
    main()
