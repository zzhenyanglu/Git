#!/usr/bin/env python3
"""
Compute AR(2) model for cmort dataset using both least squares and Yule-Walker.

"""

import sys

import numpy as np
import matplotlib.pyplot as plt

import common
import ar


def main():
    if len(sys.argv) > 1:
        inpath = sys.argv[1]
    else:
        inpath = "data/cmort_series.txt"
    xt = common.read_float_series(inpath)
    n = len(xt)
    u = np.mean(xt)
    xt_mean0 = xt - u
    print("len", n)
    print("xt[0], xt[1]", xt[0], xt[1])
    print("mean", u)

    # solve using linear regression
    # Use mean0 version so we can compare the error matrix with the
    # asymptotic distribution for part (b).
    (sig2_w, phi_1, phi_2), M = ar.ar2_least_squares_mean0(xt_mean0)
    alpha = u * (1 - phi_1 - phi_2)

    print("\n= AR(2) model (least squares regression):")
    print("  alpha   =", alpha)
    print("  phi_1   =", phi_1)
    print("  phi_2   =", phi_2)
    print("  sig2_w  =", sig2_w)
    print()

    # For part (b), calculate covariance matrix for least squares and
    # the expected asymptotic covariance.

    # Least squares method has covariance matrix:
    #   sigma^2_w (Z^T Z)^{-1} [Shumway 2.9]
    # Note that the unbiased estimator for sigma^2_w, SSE / (n-q), is
    # distributed chi-squared with (n-q) degrees of freedom. For AR(2)
    # fit with no intercept term, q=2.
    phi_cov_llsq = np.linalg.inv(M) * sig2_w
    print("(b) Dist(phi_1, phi_2) ~ bivariate normal with covariance:")
    print("estimated error distribution:")
    print(phi_cov_llsq)

    # From Shumway example 3.3, for AR(2) the asymptotic distribution of
    # parameters is joint normal with covariance matrix:
    #   1/n *
    #   [ 1 - phi_2^2         -phi_1(1 + phi_2) ]
    #   [ -phi_1(1 + phi_2)         1 - phi_2^2 ]
    #
    a = 1 - phi_2**2
    b = -phi_1 * (1 + phi_2)
    phi_cov_asym = np.array([[a, b], [b, a]]) / n
    print("asymptotic error distribution:")
    print(phi_cov_asym)

    # solve using Yule-Walker
    sig2_w, (phi_1, phi_2) = ar.fit_yw(xt_mean0, 2)
    alpha = u * (1 - phi_1 - phi_2)

    print("\n= AR(2) model (Yule-Walker):")
    print("  alpha   =", alpha)
    print("  phi_1   =", phi_1)
    print("  phi_2   =", phi_2)
    print("  sig2_w  =", sig2_w)
    plt.figure()
    ar.plot_series_with_ar2_estimator(xt, alpha, phi_1, phi_2,
                                      noise_var=sig2_w)
    plt.show()


if __name__ == "__main__":
    main()
