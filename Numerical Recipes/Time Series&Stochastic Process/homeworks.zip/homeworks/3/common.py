"""
Helper routines for question from Time Serieas Analysis and its Applications
by Shumway.
"""
import csv

import numpy as np

import matplotlib.pyplot as plt


def read_float_series(path):
    """
    Read a linear series of floating point strings, separated by newlines,
    as a numpy array.
    """
    data = []
    with open(path) as f:
        for line in f:
            data.append(float(line.strip()))
    return np.array(data)


def read_float_table(path, exclude_cols=None):
    """
    Read a table of time series as a numpy 2d array. First row of input is
    assumed to be names. Different observables are in different columns, and
    each row is a different time.

    exclude_cols can be used to exclude some columns, e.g. "Time"

    Returns (names, matrix)
    """
    data = {}
    if exclude_cols is None:
        exclude_cols = set()
    else:
        exclude_cols = set(exclude_cols)
    npoints = 0
    with open(path, newline='') as f:
        reader = csv.reader(f, delimiter="\t")
        headers = next(reader)
        for head in headers:
            if head in exclude_cols:
                continue
            data[head] = []
        for row in reader:
            for i, cell in enumerate(row):
                head = headers[i]
                if head in exclude_cols:
                    continue
                data[head].append(float(cell.strip()))
            npoints += 1

    for h in exclude_cols:
        headers.remove(h)

    nseries = len(headers)

    M = np.empty((npoints, nseries), dtype=np.float64)
    for i, h in enumerate(headers):
        M[:,i] = data[h]

    return (headers, M)


def acov(x, maxlag=None):
    """
    Estimate auto covariance function of a time series at different lags,
    assuming stationarity.

    See Shumway 3rd ed, def 1.8, p24.

    Use denominator n=len(x).

    Returns numpy array of covariances at different lag values, from 0 to
    maxlag (default len(x)-1).
    """
    n = x.shape[0]

    if maxlag is None:
        maxlag = n - 1
    assert maxlag < n

    u = np.mean(x)
    v = np.var(x)
    covar = np.zeros(maxlag + 1, dtype=np.float)
    covar[0] = v
    for h in range(1, maxlag + 1):
        for i in range(n-h):
            covar[h] += (x[i] - u) * (x[i+h] - u)
    covar /= n
    covar[0] = v
    return covar

# backward compat name
auto_covar_stationary = acov


def get_noise(n, var=1, mean=0):
    return np.random.normal(mean, np.sqrt(var), size=n)


def acf(x, maxlag=None):
    """
    Esimate auto correlation function of a time series at different lags,
    assuming stationarity.

    See Shumway 3rd ed, def 1.9, p2.

    Uses denominator n=len(x).

    Returns numpy array of auto correlations at different lag values, from 0 to
    maxlag (default len(x)-1). Note that the zeroth term will always be 1.
    """
    n = len(x)

    if maxlag is None:
        maxlag = n - 1
    assert maxlag < n

    u = np.mean(x)
    v = np.var(x)
    corr = np.zeros(maxlag + 1, dtype=np.float)
    corr[0] = 1
    for h in range(1, maxlag + 1):
        for i in range(n-h):
            corr[h] += (x[i] - u) * (x[i+h] - u)
    corr /= (n * v)
    corr[0] = 1
    return corr


def pacf(x, maxlag=None, xacf=None):
    """
    Esimate partial auto correlation function of a time series at different
    lags, assuming stationarity.

    Uses Levinson-Durbin recursion.
    See Shumway 3rd ed, Property 3.5 and eq 3.69 p115

    Returns numpy array of auto correlations at different lag values, from 0 to
    maxlag (default len(x)-1). Note that the zeroth term will always be 1
    by convention.
    """
    n = len(x)

    if maxlag is None:
        maxlag = n - 1
    assert maxlag < n

    if xacf is None:
        xacf = acf(x, maxlag=maxlag)
    else:
        assert len(xacf) >= maxlag+1

    # phi_nn
    xpacf = np.empty(maxlag+1, dtype=np.float64)
    # phi_(n-1)k for current value of n and k = 1...n-1
    # alternate between two arrays across iterations
    xpacf_sub = np.empty(maxlag+1, dtype=np.float64)
    xpacf_sub2 = np.empty(maxlag+1, dtype=np.float64)

    xpacf[0] = 1 # by convention, and to keep index == lag
    xpacf[1] = xacf[1]
    xpacf_sub[1] = xpacf[1] # only value used when n=2

    # tracks P_i^{i+1}, P_0^1 = gamma(0) = var(x)
    # TODO: not needed for PACF, but statsmodels uses it as part of an
    # iterative way of calculating the denominator, so it may be more
    # efficient
    #pnn1 = np.var(x) * (1 - xacf[1,1]**2)

    for i in range(2, maxlag+1):
        xpacf[i] = ((xacf[i] - np.dot(xacf[i-1:0:-1], xpacf_sub[1:i]))
                    / (1 - np.dot(xacf[1:i], xpacf_sub[1:i])))
        #pnn1 *= (1 - xpacf[i,i]**2)

        # calculat next phi_nk
        for j in range(1, i):
            xpacf_sub2[j] = xpacf_sub[j] - xpacf[i] * xpacf_sub[i-j]
        xpacf_sub2[i] = xpacf[i]

        # swap xpacf_sub and sub2
        tmp = xpacf_sub
        xpacf_sub = xpacf_sub2
        xpacf_sub2 = tmp

    return xpacf


# backward compat name
auto_corr_stationary = acf


def plot_acf(xacf, ax=None):
    """
    Vertical line plot suitable for acf or pacf data.
    """
    if ax is None:
        ax = plt
    lags = np.arange(len(xacf))
    ax.vlines(lags, [0], xacf, lw=2)
    ax.axhline()


def plot_cfs(xacf, xpacf):
    """
    Plot both ACF and PACF vertically on same figure.
    """
    assert len(xacf) == len(xpacf)

    fig, (ax1, ax2) = plt.subplots(2, sharex=True)
    plot_acf(xacf, ax1)
    ax1.set_ylabel("ACF")
    ax2.set_xlabel("lag")

    plot_acf(xpacf, ax2)
    ax2.set_xlabel("lag")
    ax2.set_ylabel("PACF")

    return fig


def sum_squared_error(xt, xt2):
    """
    Calculate SSE for two time series of the same length.
    """
    assert len(xt) == len(xt2)
    return np.sum((xt - xt2)**2)


def test():
    nlags = 10
    # compare with known correct statsmodels module
    from statsmodels.tsa import stattools
    xt = get_noise(10000, 34.123)
    print("mean", np.mean(xt))
    print("var ", np.var(xt))

    acov1 = acov(xt, nlags)
    acov2 = stattools.acovf(xt)[:nlags+1]
    print("acov", acov1)
    print("ACOV", acov2)
    print("diff", acov1 - acov2)
    print("err ", sum_squared_error(acov1, acov2))
    print()

    acf1 = acf(xt, nlags)
    acf2 = stattools.acf(xt, nlags=nlags)
    print("acf ", acf1)
    print("ACF ", acf2)
    print("diff", acf1 - acf2)
    print("err ", sum_squared_error(acf1, acf2))
    print()

    pacf1 = pacf(xt, nlags)
    pacf2 = stattools.pacf(xt, nlags=nlags, method="ldb")
    print("pacf", pacf1)
    print("PACF", pacf2)
    print("diff", pacf1 - pacf2)
    print("err ", sum_squared_error(pacf1, pacf2))
    print()


if __name__ == "__main__":
    test()
