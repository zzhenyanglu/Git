#!/usr/bin/env python3
"""
Problem 3.20 p170.

This is actually a pure white noise system, basically ARMA(0,0), because
the parameters are reduntant and factor out. This shows up in the ACF and
PACF which look random. Attempting to fit an ARMA(1,1) sometimes succeeds
with an arbitrary phi ~= -theta result, sometimes results in overflow and
NaN parameters, and sometimes results in a singular matrix in one of the
iterations and blows up.
"""

import sys

import numpy as np
import matplotlib.pyplot as plt

import common
import arma


def ex37():
    """
    Test using Ex 3.7 params, or params from command line args.
    """
    if len(sys.argv) == 3:
        phi = float(sys.argv[1])
        theta = float(sys.argv[2])
    else:
        phi = 0.9
        theta = 0.5
    simulate_and_fit(phi, theta)


def simulate_and_fit(phi, theta, n=1000, niters=20, nlags=40):
    xt = arma.arma_generate(n, np.array([phi]), np.array([theta]))
    print("mean", np.mean(xt))
    print("var ", np.var(xt))
    print("actual  ", phi, theta)
    xacf = common.acf(xt, nlags)
    xpacf = common.pacf(xt, nlags)
    phi2, theta2, sigma2_w = arma.arma11_fit(xt, niters=20)
    print("estimate", phi2, theta2, sigma2_w)
    #fig = common.plot_cfs(xacf, xpacf)
    #plt.show()


def main():
    n = 500
    phi = np.array([0.9])
    theta = np.array([-0.9])

    xt = arma.arma_generate(n, phi, theta)
    print("mean", np.mean(xt))
    print("var ", np.var(xt))
    print("gen model", phi[0], theta[0])
    nlags = 40
    xacf = common.acf(xt, nlags)
    xpacf = common.pacf(xt, nlags)
    fig = common.plot_cfs(xacf, xpacf)
    phi2, theta2, sigma2_w = arma.arma11_fit(xt)
    print("estimate", phi2, theta2, sigma2_w)
    plt.figure()
    plt.plot(xt, marker=".", linestyle="-")
    plt.show()


if __name__ == "__main__":
    #ex37()
    main()
