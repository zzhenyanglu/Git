#!/usr/bin/env python3
"""
For testing, run against rec_series.txt, and verify params with Ex 3.17
p111 in Shumway 3rd ed.
"""

import sys

import numpy as np
import matplotlib.pyplot as plt

import common
import ar



def main():
    if len(sys.argv) > 1:
        inpath = sys.argv[1]
    else:
        inpath = "data/cmort_series.txt"
    xt = common.read_float_series(inpath)
    u = np.mean(xt)
    n = len(xt)
    print("len", n)
    print("xt[0], xt[1]", xt[0], xt[1])
    print("mean", u)

    (noise_var, alpha, phi_1, phi_2), _ = ar.ar2_least_squares(xt)
    u2 = alpha / (1 - phi_1 - phi_2)
    print("mean (alpha estimate)", u2)
    print("\n= AR(2) model:")
    print("  alpha   =", alpha)
    print("  phi_1   =", phi_1)
    print("  phi_2   =", phi_2)
    print("  sig_w^2 =", noise_var)
    ar.plot_series_with_ar2_estimator(xt, alpha, phi_1, phi_2)

    # forecast next four terms using the AR(2) model
    xt_next = ar.ar2_generate(alpha, phi_1, phi_2, xt[-2], xt[-1], 4)
    print("\n= Forecast for next four terms:")
    for i, x in enumerate(xt_next):
        conf = ar.ar2_confidence(n, i+1, phi_1, phi_2, noise_var)
        print(" ", x, "+/-", conf)

    plt.show()


if __name__ == "__main__":
    main()
