#!/usr/bin/env julia
#=
Simulate AR(2) model x_t = -0.9x_{t-2} + w_t, and generate plots to compare
it's sample ACF to the analytic ACF.

Produces 'shumway36_ar2_acf.png'.
=#

using Gadfly
using QuantEcon
using StatsBase

ACF_MAX = 20

# analyticly determined ACF
theory_acf(x) = (3/sqrt(10))^x * cos(pi*x/2)
theory_layer = layer(theory_acf, 0, ACF_MAX)

# simulate and compute ACF
ar2 = QuantEcon.ARMA([0, -0.9], [], 1)
sim_data = QuantEcon.simulation(ar2, ts_length=1000)
lags = collect(0:min(length(sim_data)-1,ACF_MAX))
sim_acf = autocor(sim_data, lags)
sim_layer = layer(y=sim_acf, xmin=lags-0.1, xmax=lags+0.1, Geom.bar)


# NOTE: place xticks to coincide with period, force white background
p = plot(sim_layer, theory_layer,
         Guide.xticks(ticks=collect(0:4:ACF_MAX)),
         Theme(background_color=colorant"white"))
Gadfly.draw(PNG("shumway36_ar2_acf.png", 800px, 600px), p)
