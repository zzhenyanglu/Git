"""
Functions for AR(p) models.
"""

import numpy as np
import matplotlib.pyplot as plt

import common


def ar2_least_squares(xt):
    """
    Use least squares method to find AR(2) model for time series xt. Does
    NOT assume that xt has zero mean.

    Returns ((sigma2_w, alpha, phi_1, phi_2), M), where alpha is the intercept
    term, related to the mean u by alpha = u * (1 - phi_1 - phi_2).
    M is the matrix (Z^T Z), which is useful for calculating the covariance
    matrix for the joint normal distribution of the error (see Shumway 2.9, p).
    """
    # setup up matrix, with rows (1, x_{t-1}, x_{t-2})
    n = len(xt)
    assert n > 2
    rows = len(xt)-2
    cols = 3
    Z = np.empty((rows, cols))
    Z[:,0] = np.ones(rows)
    Z[:,1] = xt[1:n-1]
    Z[:,2] = xt[:n-2]
    Zt = Z.transpose()
    M = Zt.dot(Z)
    b = Zt.dot(xt[2:])
    (alpha, phi_1, phi_2) = np.linalg.solve(M, b)
    SSE = np.sum(np.square(xt[2:] - Z.dot([alpha, phi_1, phi_2])))
    # unbiased estimator (not the MLE!) for least squares, see Shumway
    # 2.11, p50
    sigma2_w = SSE / (n-cols)
    return (sigma2_w, alpha, phi_1, phi_2), M


def ar2_least_squares_mean0(xt):
    """
    Use least squares method to find AR(2) model for time series xt. DOES
    assume that xt has zero mean.

    Returns ((sigma2_w, phi_1, phi_2), M)
    M is the matrix (Z^T Z), which is useful for calculating the covariance
    matrix for the joint normal distribution of the error (see Shumway 2.9, p).
    """
    # setup up matrix, with rows (x_{t-1}, x_{t-2})
    n = len(xt)
    assert n > 2
    rows = len(xt)-2
    cols = 2
    Z = np.empty((rows, cols))
    Z[:,0] = xt[1:n-1]
    Z[:,1] = xt[:n-2]
    Zt = Z.transpose()
    M = Zt.dot(Z)
    b = Zt.dot(xt[2:])
    (phi_1, phi_2) = np.linalg.solve(M, b)
    SSE = np.sum(np.square(xt[2:] - Z.dot([phi_1, phi_2])))
    # unbiased estimator (not the MLE!) for least squares, see Shumway
    # 2.11, p50
    sigma2_w = SSE / (n-cols)
    return (sigma2_w, phi_1, phi_2), M


def ar2_generate(alpha, phi_1, phi_2, x0, x1, n, noise_var=0):
    """
    Generate n values of AR(2) sequence, with x0 and x1 as initial values and
    parameters alpha, phi_1, phi_2.

    If noise_var > 0, add white noise with specified variance.
    """
    assert n > 2
    xt = np.empty(n)
    xt[0] = x0
    xt[1] = x1
    if noise_var > 0:
        w = common.get_noise(n, var=noise_var)
    else:
        w = np.zeros(n)

    for i in range(2, n):
        xt[i] = alpha + phi_1 * xt[i-1] + phi_2 * xt[i-2] + w[i]

    return xt


def ar_generate(n, phi, iv, noise_var=0):
    """
    Generate n values of a zero mean AR(p) process with coefficients from phi,
    initial values in iv, and specified noise variance.
    """
    xt = np.empty(n)
    p = len(phi)
    assert len(iv) == p
    xt[:p] = iv
    phi_r = np.flipud(phi)
    if noise_var > 0:
        w = common.get_noise(n, var=noise_var)
    else:
        w = np.zeros(n)
    for i in range(p, n):
        xt[i] = np.dot(phi_r, xt[i-p:i]) + w[i]
    return xt


def ar2_estimate_white_noise_var(xt, phi_1, phi_2):
    """
    Estimate white noise variance of an AR(2) process with parameters
    phi_1 and phi_2, using the auto covariance:

      sigma_w^2 = gamma(0) - phi_1 * gamma(1) - phi_2 * gamma(2)

    See Shumway Definition 3.10 for Yule-Walker equations, Eq 3.99, p124
    """
    gamma = common.auto_covar_stationary(xt, maxlag=2)
    return gamma[0] - phi_1 * gamma[1] - phi_2 * gamma[2]


def plot_series_with_ar2_estimator(xt, alpha, phi_1, phi_2, noise_var=None):
    """
    Plot time series xt along with points estimated with AR(2) model
    x_t = alpha + phi_1 x_{t-1} + phi_2 x_{t-2} with and without noise
    """
    xt2 = ar2_generate(alpha, phi_1, phi_2, xt[0], xt[1], len(xt))

    if noise_var is None:
        noise_var = ar2_estimate_white_noise_var(xt, phi_1, phi_2)

    xt3 = ar2_generate(alpha, phi_1, phi_2, xt[0], xt[1], len(xt), noise_var)

    plt.plot(xt, marker='.', linestyle='', color='g', label="sample")
    plt.plot(xt2, marker='.', linestyle='', color='b', label="AR(2) model")
    plt.plot(xt3, marker='.', linestyle='', color='y', label="AR(2) + noise")
    plt.legend()


def ar2_confidence(n, m, phi_1, phi_2, noise_var):
    """
    Get 95% confidence interval for estimating x_{n+m} from an AR(2) model for
    a time series x_n with noise variance noise_var.

    For AR(2), psi_0 = 1, psi_1 = phi_1, psi_2 = phi_1^2 + phi_2,
    psi_j = phi_1 psi_{j-1} + phi_2 psi_{j-2}

    See Shumway 3rd ed 3.40, 3.86, and 3.93.
    """
    psi = np.empty(m)
    psi[0] = 1
    if m > 1:
        psi[1] = phi_1
    if m > 2:
        psi[2] = phi_1**2 + phi_2
        for j in range(2, m):
            psi[j] = phi_1 * psi[j-1] + phi_2 * psi[j-2]
    # Chosen for 95% confidence. Note that according to PennState stats
    # 501 at https://onlinecourses.science.psu.edu/stat510/node/66,
    # 1.96 is a more precise value. Either is fine for the homework.
    c = 2
    Pnm = noise_var * np.sum(psi**2)
    return c * np.sqrt(Pnm)


def fit_yw(xt, p):
    """
    Use Yule-Walker to estimate autoregressive fit on numeric numpy time
    series in xt, using AR parameter p. Assumes zero mean.

    Returns (sigma2_w, params), where params is a numpy array of phi
    parameters, with length p.
    """
    gamma = common.auto_covar_stationary(xt, p)
    # construct symmetric covariance matrix, with gamma(0) on diagonal
    # and successive off diagnals gamma(1), gamma(2)...
    M = np.empty((p, p))
    for i in range(p):
        M[i,i:] = gamma[0:p-i]
        M[i,:i] = gamma[i:0:-1]
    b = gamma[1:]
    beta = np.linalg.solve(M, b)
    sig2_w = gamma[0] - np.dot(beta, gamma[1:])
    return sig2_w, beta


def test():
    # See Example 3.10 p102 and Fig 3.5 p109 in Shumway 3rd ed
    # See also ex3.10.r
    phi = [1.5, -0.75]
    n = 144
    xt = ar_generate(n, phi, [.1, -.1], noise_var=1)
    lags = 25
    xacf = common.acf(xt, lags)
    xpacf = common.pacf(xt, lags)
    fig = common.plot_cfs(xacf, xpacf)
    plt.show()


if __name__ == "__main__":
    test()
