"""
Functions for generating and fitting ARMA models.

See Shumway 3rd ed Definition 3.5, p94
"""
import numpy as np
import matplotlib.pyplot as plt

import common

from ar import fit_yw


def arma_generate(n, phi, theta, noise_var=1, mean=0, iv=None):
    """
    Sumulate ARMA(p,q) process, with optional white noise.
    n: number of terms to generate
    phi: list of coefficients for auto-regressive part
    theta: list of coefficients for moving average part
    noise_var: use white noise with specified variance
    mean: mean of data to generate, default 0
    iv: optional list of initial values, must be len max(p, q). If None,
        generates random start values with +/-0.5 around mean

    Based on ARMA.m matlab example.
    """
    p = len(phi)
    q = len(theta)
    niv = max(p, q)
    if iv is None:
        iv = mean + np.random.rand(niv) - 0.5
    else:
        assert len(iv) == niv
    w = common.get_noise(n, noise_var)
    alpha = mean * (1 - np.sum(phi) - np.sum(theta))
    phi_r = np.flipud(phi)
    theta_r = np.flipud(theta)
    xt = np.empty(n, dtype=np.float64)
    xt[:niv] = iv
    for i in range(niv, n):
        xt[i] = (alpha
                 + np.dot(xt[i-p:i], phi_r)
                 + np.dot(w[i-q:i], theta_r)
                 + w[i])
    return xt


def arma11_fit(xt, maxiters=12):
    """
    Use Gauss-Newton non-linear least squares to estimate parameters for an
    ARMA(1,1) model of the timeseries xt, assumed to have zero mean.

    Returns (phi, theta), where alpha is the intercept term,
    phi is a numpy array of length p with the AR parameters, and theta
    is a numpy array of length q with the MA parameters.
    """
    p = 1
    q = 1
    n = len(xt)
    # arbitrary start values that are still causal and invertible
    phi = 0.5
    theta = 0.1
    #zt = np.empty((n,2), dtype=np.float64)

    # contains w_t's at current guess for phi and theta
    w = np.zeros(n, dtype=np.float64)
    for nit in range(maxiters):
        # set up lineraized system based on initial or previous values
        for i in range(p, n):
            w[i] = xt[i] - phi * xt[i-1] - theta * w[i-1]

        M = np.zeros((2, 2), dtype=np.float64)
        b = np.zeros(2, dtype=np.float64)
        zphi = 0
        ztheta = 0
        for i in range(p, n):
            # z_i = [zphi, ztheta]'
            zphi = xt[i-1] - theta * zphi
            ztheta = w[i-1] - theta * ztheta

            # add z_i * z'_i (outer product)
            zmul = zphi * ztheta
            M[0,0] += zphi**2
            M[0,1] += zmul
            M[1,0] += zmul
            M[1,1] += ztheta**2

            # matrix form, overkill for p+q=2
            #zt = np.array([zphi, ztheta])
            #M += np.outer(zt, zt)

            # add z_t * w_t
            b[0] += zphi * w[i]
            b[1] += ztheta * w[i]
        M /= n
        b /= n
        delB = np.linalg.solve(M, b)
        oldnorm = np.linalg.norm([phi, theta])
        phi += delB[0]
        theta += delB[1]
        # stopping criteria
        # see https://en.wikipedia.org/wiki/Non-linear_least_squares#Convergence_criteria
        if (np.linalg.norm(delB) / oldnorm) < 0.001:
            #print("stopping early", nit)
            break
    # update white noise (error) estimates based on final values, to
    # calculate SSE
    for i in range(p, n):
        w[i] = xt[i] - phi * xt[i-1] - theta * w[i-1]
    sigma2_w = np.sum(w**2) / n
    return (phi, theta, sigma2_w)


def test_generate():
    import argparse
    parser = argparse.ArgumentParser(
                description="generate and graph ARMA process")
    parser.add_argument("-p", "--phi", nargs="+", type=float, required=True,
                        help="AR coefficients")
    parser.add_argument("-t", "--theta", nargs="+", type=float, required=True,
                        help="MA coefficients")
    parser.add_argument("-u", "--mean", type=float, default=0,
                        help="mean of series to generate (default 0)")
    parser.add_argument("-n", "--count", type=int, default=1000,
                        help="number of elements to generate (default 1000)")
    parser.add_argument("-v", "--var", type=float, default=1,
                        help="white noise variance (default 1)")
    args = parser.parse_args()

    xt = arma_generate(n=args.count,
                       phi=args.phi,
                       theta=args.theta,
                       noise_var=args.var,
                       mean=args.mean)
    print("mean", np.mean(xt))
    print("var ", np.var(xt))
    plt.plot(xt, marker=".", linestyle="-")
    plt.show()


if __name__ == "__main__":
    test_generate()
