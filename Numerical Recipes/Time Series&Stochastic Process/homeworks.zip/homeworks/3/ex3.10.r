#!/usr/bin/env Rscript

library("astsa")

X11()

set.seed(90210)
ar2 = arima.sim(list(order=c(2,0,0), ar=c(1.5,-.75)), n=144)
acf2(ar2, 24)
message("Press Return To Continue")
invisible(readLines("stdin", n=1))
