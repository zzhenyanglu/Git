# Script to extract subject-averaged FMRI data for given treatments and all locations.  Each treatment will be a separate table.  Each table will have 128 timesteps for all 9 locations.  

require(astsa)

# The treatments
nTreats <- 6
treatLabels <- c("Awake_Brush", "Awake_Heat", "Awake_Shock", "Low_Brush", 
	"Low_Heat", "Low_Shock")

# The locations
nLocs <- 9
locLabels <- c("Time", "Cortex_1", "Cortex_2", "Cortex_3", "Cortex_4", 
	"Caudate", "Thalamus_1", "Thalamus_2", "Cerebellum_1", "Cerebellum_2")

# For each treatment
for (trt in 2:3) {
	# First column is timesteps
	Y <- 1:128
	# For all locations
	for (loc in 1:nLocs) {
		# Indexing scheme of fmri is (location,treatment)
		i <- (loc - 1) * nTreats + trt
		# Append the column for this location, averaged by subject
		Y <- cbind(Y, rowMeans(fmri[[i]]))
	}
	# Add column header and write to file
	colnames(Y) <- locLabels
	write.table(Y, file = paste0("./fmri.", treatLabels[trt], ".txt"), 
		sep = "\t", row.names = FALSE)
}
