function [ X ] = create_corr(mu, sigma, n, R)
% create m vectors of length n with mean mu, variance=sigma,
% and correlation matrix R
if (~all(eig(R) > eps))
    error('R not positive definite');
end
[m, ~] = size(R);
X = mu + sigma*randn(n,m);
L = chol(R);
X = X*L;

end

