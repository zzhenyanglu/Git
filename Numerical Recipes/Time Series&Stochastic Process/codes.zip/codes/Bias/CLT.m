% Simple test of the central limit theorem
% Plot the histogram of sample means of a 
% Uniform Random Process

ns = 500000; % number of sample means
n  = 1000;   % sample size

s = zeros(1,ns); % create vector of sample means
for i=1:ns       % create each sample mean
    r = randi(m,n,1); 
    s(i) = sqrt(n)*mean(r);
end

histogram(s,100); % show Gaussian distribution