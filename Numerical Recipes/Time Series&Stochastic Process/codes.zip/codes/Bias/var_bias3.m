function [r] = var_bias3(rho,n)
%explicitly calculate the bias in variance estimate for specified
%sampled ACF rho
sumTerm = 0;
m = numel(rho); %assume rho=0 from m:n
for k=1:m
    sumTerm = sumTerm + (1-k/n)*rho(k);
end
r = 1 - 2/(n-1)*sumTerm;
end