hold on;
n = [100,1000,10000];
ncases = numel(n);
m=50000;

varu = zeros(1,m);
for j=1:ncases
    disp(j);
    for i = 1:m                           % m sample variances
        g = rand(1,n(j));                    % n i.i.d. samples
        g_ave = mean(g);
        varu(i) = 1/(n(j)-1) * sum((g-g_ave).^2); %unbiased for correlated samples
    end
    histogram(varu,'DisplayStyle', 'stairs','Normalization','pdf');
end