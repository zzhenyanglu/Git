nmax = 10000000;
n = 10000:50000:nmax;
f = ARp(nmax,phi);
varf = zeros(1,numel(n));
phi = .9;
for i=1:numel(n)
    disp(i);
    varf(i) = var(f(1:n(i)));
end

plot(n,varf);