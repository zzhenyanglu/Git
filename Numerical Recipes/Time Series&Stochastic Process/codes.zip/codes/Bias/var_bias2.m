%generate exponential autocorrelated time series and show
%distribution of biased sample variance as function of number
% of points
phi = .7;

%f = ARp(n,phi);
%acf = ACF(f);
%acf_data = acf(1:50);
%acf_theory = phi.^(1:50);
%plot(acf_data,'-');
%hold on;
%plot(acf_theory,'-.');

hold on;
n = [100,1000,10000];
ncases = numel(n);
m=50000;

varu = zeros(1,m);
for j=1:ncases
    disp(j);
    for i = 1:m                           % m sample variances
        g = ARp(n(j),phi);                % n autocorrelated samples
        g_ave = mean(g);
        varu(i) = 1/(n(j)-1) * sum((g-g_ave).^2); %unbiased for correlated samples
    end
    histogram(varu,'DisplayStyle', 'stairs','Normalization','pdf');
end