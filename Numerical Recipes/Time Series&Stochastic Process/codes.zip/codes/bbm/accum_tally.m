function [tally] = accum_tally(tally,x,nn,xmin,ymin,hx,hy)
%  given an n X 1 tally array and an m X 2 list of particle
%  coordinates update the number of particles in each tally bin

k = floor((x(:,1)-xmin)/hx) + nn*floor((x(:,2)-ymin)/hy) + 1;
[m,k] = hist(k,unique(k));
tally(k) = tally(k) + m';

end

