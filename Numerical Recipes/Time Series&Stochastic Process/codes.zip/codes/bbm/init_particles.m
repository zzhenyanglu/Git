function [ x ] = init_particles( xmin,xmax,ymin,ymax,n )
x  = [xmin+(xmax-xmin)*rand(n,1) ...
    ymin+(ymax-ymin)*rand(n,1)];
%x = [xmin + (xmax-xmin)/2*ones(n,1), ...
%     ymin + (ymax-ymin)/2*ones(n,1)];
end

