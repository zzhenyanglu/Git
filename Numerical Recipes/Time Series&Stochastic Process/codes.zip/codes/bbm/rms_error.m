function [ err ] = rms_error( xexact, xguess )
%compute root mean square error given exact solution
%and current guess on rectangular tally mesh
xguess = xguess/sum(xguess);
err = sqrt(sum((xexact - xguess).^2));

end

