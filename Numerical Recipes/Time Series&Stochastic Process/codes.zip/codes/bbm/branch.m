function [ x, btimes ] = branch( x, btimes, t, lambda )

bdi = find(t >= btimes);
m = numel(bdi);

% how many die?
md = numel(find((rand(m,1) > .5)));

% the rest branch
mb = m - md;

% store birth and death indexes separately
di = bdi(1:md);
bi = bdi(md+1:m);

% create new list by removing md from bd and adding mb duplicates
x(di,:)      = NaN;
btimes(di,:) = NaN;

% duplicate births at end of array
x = [x; x(bi,:)];

% add branching time for new particles
btimes = [btimes;t-log(rand(mb,1))/lambda];

%update branching times for branched particles
btimes(bi) = t-log(rand(mb,1))/lambda;

% remove NaN rows
x(any(isnan(x),2),:) = [];
btimes(isnan(btimes)) = [];


end

