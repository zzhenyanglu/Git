xmin=-5; xmax=5;                 % box byoundaries
ymin=-5; ymax=5;
itally  = 20;                      % tally frequency
nn      = 20;                      % nnxnn square array of tally bins
hx      = (xmax-xmin)/nn;          % tally spacing
hy      = (ymax-ymin)/nn;
A       = (xmax-xmin)*(ymax-ymin); % area of box
n       = 1000;                    % number of particles
tf      = 10;                      % final simulation time
nsteps  = 1000;                    % number of timestep
D       = .01;                     % diffusivity
dt      = tf/nsteps;
sigma   = sqrt(2*D*dt);            % sigma^2 = 2*D*dt for random walk
t       = 0.0;                     % initial time
lambda  = 1;
btimes  = -log(rand(n,1))/lambda;  % branching times
bnd     = 1;                       % periodic (1) or reflecting (2)

% initialize particles
x = init_particles(xmin,xmax,ymin,ymax,n); 
exact = ones(nn^2,1)/nn^2;

% setup and get handle to graphics object
hn = graphics(x,xmin,xmax,ymin,ymax,hx,hy,itally);

if (itally > 0)
    k = 0;                         % counter for number of times tallied
    ntally = floor(nsteps/itally); % number of times tallied
    tally  = zeros(nn^2,1);        % pre-allocate tally data storage
    h = 0.01;                      % search radius for L function
    L = zeros(ntally,1);           % Ripley's L function
    r = zeros(ntally,1);           % mean nearest neighbor distance
    err = zeros(ntally,1);
    s = zeros(ntally,1);           % mean distance between pairs
end

for i = 1:nsteps                         
    fprintf(1,'time: %f  particles: %d\n', t, n);    %print diagnostic
    set(hn,'XData',x(:,1),'YData',x(:,2)); drawnow;  %scatter plot
    x = bmstep(x,sigma,bnd,xmin,xmax,ymin,ymax);     %brownian step
    [x, btimes] = branch(x,btimes,t,lambda);         %compute branches
    n = size(x,1);                                   %update size
    if (mod(i,itally) == 0)
        k = k + 1;
        tally = accum_tally(tally,x,nn,xmin,ymin,hx,hy);
        err(k) = rms_error(exact, tally);
    end
    t = t + dt;
end

