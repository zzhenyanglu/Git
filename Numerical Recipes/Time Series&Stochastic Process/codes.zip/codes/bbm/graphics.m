function [ hn ] = graphics( x,xmin,xmax,ymin,ymax,hx,hy,itally )

figure('Color','w'); hold on;
hn = scatter(x(:,1),x(:,2),2,'.k');
set(gca,'xlim',[xmin xmax],'ylim',[ymin ymax]);
set(gca,'visible','off');
daspect([1 1 1]);

% Plot tally grids
if (itally > 0)
    for i=xmin:hx:xmax
        plot([ymin ymax],[i i],'Color',[.7 .7 .7]);
    end
    for i=ymin:hy:ymax
        plot([i i],[xmin xmax],'Color',[.7 .7 .7]);
    end
end
rectangle('Position',[xmin ymin xmax-xmin ymax-ymin])

end

