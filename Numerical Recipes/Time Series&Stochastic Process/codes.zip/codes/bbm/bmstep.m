function [ xnew ] = bmstep( x, sigma, bnd, xmin, xmax, ymin, ymax )

[n, ~] = size(x);

% one step in random walk
dr = randn(n,2)*sigma;
theta = acos(rand(n,1));
dx = dr(:,1).*cos(theta);
dy = dr(:,2).*sin(theta);
xnew = x + [dx dy];

% periodic boundaries
if (bnd == 1)
    xbr = find(xnew(:,1) > xmax); xnew(xbr,1) = xmin - xmax + xnew(xbr,1);
    xbl = find(xnew(:,1) < xmin); xnew(xbl,1) = xmax - xmin + xnew(xbl,1);
    xbu = find(xnew(:,2) > ymax); xnew(xbu,2) = ymin - ymax + xnew(xbu,2);
    xbd = find(xnew(:,2) < ymin); xnew(xbd,2) = ymax - ymin + xnew(xbd,2);
elseif (bnd == 2)
    % reflective boundaries
    xbr = find(xnew(:,1) > xmax); xnew(xbr,1) = 2*xmax - xnew(xbr,1);
    xbl = find(xnew(:,1) < xmin); xnew(xbl,1) = 2*xmin - xnew(xbl,1);
    xbu = find(xnew(:,2) > ymax); xnew(xbu,2) = 2*ymax - xnew(xbu,2);
    xbd = find(xnew(:,2) < ymin); xnew(xbd,2) = 2*ymin - xnew(xbd,2);
end

end

