function X = sample(pdf)
    % Samples a random number from a CDF
    cdf = cumsum(pdf);
    U = rand(1);
    for i = 1 : numel(cdf)-1
        if U < cdf(i)                % first index of cdf such that U > cdf is ~ x at which cdf(x) = U 
            X = i;
            return
        end
    end
    X = numel(cdf);
end