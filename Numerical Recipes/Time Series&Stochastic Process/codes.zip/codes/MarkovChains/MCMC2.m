function X = MCMC2(m,n,X0,Q,P)
% m: burn in, m < n
% n: steps in markov chain
% X0: initial state
% Q: transition matrix
% P: target distribution (not necessarily normalized)
X = zeros(1,n); X(1) = X0;

for i=1:n
    %sample from trial matrix
    Y = sample(Q(X(i),:));
    %decide probability of accepting based on M-H ratio
    accProb = P(Y)/P(X(i))*Q(Y,X(i))/Q(X(i),Y);
    %choose random number to see if candidate was accepted
    u = rand;
    if (u <= accProb)
        X(i+1) = Y;
    else
        X(i+1) = X(i);
    end

end
X = X(m+1:n);
end
 
 
