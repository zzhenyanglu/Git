%Example 1: Use MH with arbitrary trial matrix and simple PMF
P = [1/12 2/12 3/12 3/12 2/12 1/12];
N = length(P);
%create random trial Markov matrix
Q = [.2 .2 .2 .2 .3 .1;
    .2 .2 .2 .2 .3 .1;
    .2 .2 .2 .2 .3 .1;
    .2 .2 .2 .2 .3 .1;
    .2 .2 .2 .2 .3 .1;
    .2 .2 .2 .2 .2 .2];

for i=1:N; Q(i,:) = Q(i,:)/sum(Q(i,:)); end;

n = 1010000;
X = MCMC2(1000,n,1,Q,P);
disp(histc(X,1:N)/n);
disp(P);

 