% integrate f(x) = exp(-x^2/2) from -1 to 1 using monte carlo
% choose p(x) = 1/(b-a) = 1/2 and h(x) = (b-a)*exp(-x^2/2) = 2exp(-x^2/2)

a = -1; b = 1;
I = 0;
ns = 100000;
for i=1:ns
    x = a + (b-a).*rand;
    I = I + (b-a)*exp(-x^2/2)/sqrt(pi);
end

disp(I/ns);

% integrate f(x) = exp(-x^2/2) from -1 to 1 using monte carlo
% choose p(x) = 1/sqrt(2*pi)*exp(-x^2/2) and 
% h(x) = e^(-x^2/2)/p(x) = sqrt(2*pi)
% f(x) = exp(-x^2/2)
% int(f(x) dx)  = int(p(x) * f(x)/p(x) dx) = int (p(x) g(x) dx)
% f(x) = exp(-x^2/2);
% p(x) = 1/a exp(-x^2/2) with a = sqrt(2*pi)*;
% f(x)/p(x) = sqrt(2*pi)

for i=1:ns
    x = normrnd(1,1);
    I = I + 