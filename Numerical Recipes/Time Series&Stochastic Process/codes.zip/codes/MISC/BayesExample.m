%Given two bags:
% bag A: 700 red balls; 300 blue balls
% bag B: 300 red balls; 700 blue balls
% pick a bag randomly
% then choose 12 balls with replacement
% if 8 red and 4 blue are chosen
% what is chance that red-dominated bag was selected?
% Analytically we can use binomial theorem with Bayes' theorem
%
% P(C|A): Probability of 8 red/ 4 blue given bag A
% bernoulli trials
%  n : # trials
%  k : # successes
%  n-k : # failures
%  p : probability of success of one trial
%  q = 1-p : probability of faiulre of one trial
%
%  P(k successes in n trials) = n choose k * p^k * q^(n-k)
% 
%  In this experiment
%  n = 12
%  k = 8 (success means pick red ball)
%  n-k = 4
%  p = 7/10
%  q = 3/10
% P(C|A) = 12 choose 8 * (.7)^8 * (.3)^4
% Similarly
% P(C|B) = 12 choose 8 * (.3)^8 * (.7)^4
%
% Given that P(A|C)/P(B|C) = P(C|A)/P(C|B) * P(A)/P(B)
% and P(A) = P(B) = .5
% This gives P(A|C)/P(B|C) = .0337
% and P(A|C) + P(B|C) = 1 yields answer: 96.63% chance bag was
% red-dominated
%
% we can test this experimentally:

bags = [zeros(1,700) ones(1,300); ones(1,700) zeros(1,300)];
redhits = 0; bluehits = 0;
hits = zeros(1,2);

for j = 1:100000
    bag = randi([1 2]);
    selections = bags(bag,randi([1 1000],1,12));
    if ( (numel(selections(selections == 0)) == 8) && ...
            (numel(selections(selections == 1)) == 4))
        hits(bag) = hits(bag) + 1;
    end

end

disp(hits(1)/sum(hits));