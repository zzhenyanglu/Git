#!/usr/bin/env julia


function birthday_simulation(npeople, nsim, nmatches=2, ndays=365)
    hits = 0
    for i in 1:nsim
        bdays = rand(1:ndays, npeople)
        counts = Dict{Int64,Int64}()
        for j in 1:npeople
            bday = rand(1:ndays)
            counts[bday] = get(counts, bday, 0) + 1
        end
        for count in values(counts)
            if count >= nmatches
                hits += 1
                break
            end
        end
    end
    return hits / nsim
end


# See
# https://en.wikipedia.org/wiki/Birthday_problem#Cast_as_a_collision_problem
function p_birthday2(npeople, ndays=365)
    if npeople > ndays
        return 1
    end
    p = 1
    for i = 1:npeople-1
        p *= (1 - i / ndays)
    end
    return 1 - p
end


NSIM = 100000

# Compare to table at
# https://en.wikipedia.org/wiki/Birthday_problem#Calculating_the_probability
for npeople in [1, 5, 10, 20, 23, 30, 40, 50, 60, 70, 100]
    expected = p_birthday2(npeople)
    simulated = birthday_simulation(npeople, NSIM)
    println(expected, " ", simulated, " ", expected-simulated)
end
