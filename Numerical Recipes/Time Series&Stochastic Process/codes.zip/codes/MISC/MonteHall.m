function win = MonteHall(method)
% method = 1: stay with original guess
% method = 2: switch after Hall reveal

win = false;
x = randi([1 3]);           %prize door
y = randi([1 3]);           %audience choice
z = setdiff([1 2 3],[x y]); %monte hall reveal
z = z(randi([1 numel(z)]));
if (method ~= 1)
    y = setdiff([1 2 3],[y z]);
end
if (y == x) 
    win = true;
end
    