hold off;
np = 100000;
p = .5;
m = 20;
tally = zeros(1,m);
for i=1:np
    disp(i);
    absorbed = false;
    nsteps = 0;
    while (absorbed == false)
        nsteps = nsteps + 1;
        r = rand;
        if (r < p)
            absorbed = true;
        end
    end
    tally(nsteps) = tally(nsteps) + 1;
end
semilogy(tally/np,'o-');
hold on;
semilogy(diff(1-(1-p).^(0:m)),'x-')
