function [ p ] = birthday( n, m, nmatches)
count = 0;          
for i=1:m
    r = randi(365,n,1); 
    temp = hist(r,unique(r));
    if (max(temp) >= nmatches)
        count = count + 1;
    end
end
p = count/m;
end

