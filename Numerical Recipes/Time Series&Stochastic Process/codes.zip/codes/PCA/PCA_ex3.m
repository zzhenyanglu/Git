readdata;
data = [climate,housing,healthcare,crime,transp,educ,arts,recreat,econ];