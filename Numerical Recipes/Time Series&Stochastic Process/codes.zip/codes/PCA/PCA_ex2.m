% create a set of m correlated variables each with
% n observations. This is stored as an nxm matrix, ie. one
% column per variable. The do the PCA analysis returning
% an mxm matrix coeffs such that the i'th column of coeff
% stores the coefficients of the linear combination 
% of the x's for the i'th principal component.
mu = 0;
sigma = 1;
n = 10000;
R = [1.0, .75, .60,.03, .08; ...
     .75, 1.0, .07,.10, .02; ...
     .60, .07, 1.0,.05, .05; ...
     .03, .10, .05,1.0, .82; ...
     .08, .02, .05,.82, 1.0];
 
x = create_corr(mu, sigma, n, R);
figure(1);
subplot(5,1,1); plot(x(:,1));
subplot(5,1,2); plot(x(:,2));
subplot(5,1,3); plot(x(:,3));
subplot(5,1,4); plot(x(:,4));
subplot(5,1,5); plot(x(:,5));

coeffs = pca(x);
y = x*coeffs;
v1 = var(y);
[y2,P, v] = PCASimple(x');
v2 = var(y2');

figure(2);
subplot(5,1,1); plot(y(:,1));
subplot(5,1,2); plot(y(:,2));
subplot(5,1,3); plot(y(:,3));
subplot(5,1,4); plot(y(:,4));
subplot(5,1,5); plot(y(:,5));