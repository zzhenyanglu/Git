%% Initialize variables.
filename = '/Users/andrewsiegel/Dropbox/courses/58020/mpcs58020_2017/datasets/places.txt';
delimiter = '\t';

formatSpec = '%q%f%f%f%f%f%f%f%f%f%*s%*s%*s%*s%*s%[^\n\r]';

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to format string.
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter,  'ReturnOnError', false);

%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

%% Allocate imported array to column variable names
city = dataArray{:, 1};
climate = dataArray{:, 2};
housing = dataArray{:, 3};
healthcare = dataArray{:, 4};
crime = dataArray{:, 5};
transp = dataArray{:, 6};
educ = dataArray{:, 7};
arts = dataArray{:, 8};
recreat = dataArray{:, 9};
econ = dataArray{:, 10};


%% Clear temporary variables
clearvars filename delimiter formatSpec fileID dataArray ans;