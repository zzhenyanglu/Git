function [ x ] = ARMA( n, phi,theta )
% simulated ARMA(p.q) process of specified number of points n and
% vector of coefficients phi and theta. numel(phi) gives order of AR 
% process and numel(q) the order of the MA process
w = rand(n,1);
w = w - mean(w);
x = zeros(n,1);
p = numel(phi);
q = numel(theta);
% set first p values
for i=1:max(p,q)
    x(i) = rand - .5;
end

for i=p+1:n
    term1 = 0; term2 = 0;
    for j=1:p
        term1 = term1 + phi(j)*x(i-j);
    end
    for j=1:q
        term2 = term2 + theta(j)*w(i-j);
    end
    x(i) = term1 + term2 + w(i);   
end
end


