function [ x ] = MAq( n, theta )
% simulated AR(p) process of specified number of points n and
% vector of coefficients phi. numel(phi) gives order of AR process.
w = rand(n,1);
w = w - mean(w);
x = zeros(n,1);
p = numel(theta);
% set first p values
for i=1:p
    x(i) = rand - .5;
end

for i=p+1:n
    term = 0;
    for j=1:p
      term = term + theta(j)*w(i-j);
    end
    x(i) = term + w(i);   
end
end


