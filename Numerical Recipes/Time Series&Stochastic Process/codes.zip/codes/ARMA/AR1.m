function [ x1, x2 ] = AR1( n, phi )
%calculate AR(1) process both directly and using
%solution form

%zero mean white noise
w = randn(n,1);
w = w-mean(w);
%two AR(1) vectors
%x1: calculated via iteration
x1 = zeros(n,1);
%x2: calculated using solution
x2 = zeros(n,1);
x1(1) = randn -.5;
x2(1) = x1(1);
%need to set first point for AR(1) process
for i=2:n
    x1(i) = phi*x1(i-1) + w(i);
end
% to make identical need to add decaying initial value term
for i=2:n
    sum = 0;
    for j=0:i-2
        sum = sum + phi^j*w(i-j);
    end
   % x2(i) = phi^(i-1)*x2(1) + sum;
   x2(i) = sum;

end