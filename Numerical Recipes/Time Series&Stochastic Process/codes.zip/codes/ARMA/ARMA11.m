function [ x ] = ARMA11( n, phi,theta )
% simulated ARMA(1.1) process of specified number of points n and
% coefficients phi and theta.
w = rand(n,1);
w = w - mean(w);
x = zeros(n,1);
x(1) = rand - .5;
for i=2:n
    x(i) = phi*x(i-1) + theta*w(i-1) + w(i);
end
    

end