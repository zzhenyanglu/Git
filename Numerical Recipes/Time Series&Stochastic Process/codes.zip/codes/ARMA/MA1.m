function [ x ] = MA1( n, theta )
% compute MA(1) process for specified n and theta
w = rand(n,1);
w = w - mean(w);
x = zeros(n,1);
x(1) = rand - .5;
for i=2:n
    x(i) = w(i) + theta*w(i-1);
end


end

