%example 3.26 from shumway

n = 10000;            %n-2 values of x(t)
x = zeros(n,1);       %storage for time series
w = randn(n,1);       %iid(0,1) error term 

% create the n-3 point AR(3) process
for i=4:n
    x(i) = 1.5*x(i-1) -.75*x(i-2) + .2*x(i-3)+ w(i);
end
%ignore first two values
x=x(4:end);
% get acf lags 1 and 2 and lag 0 (variance)
ac = ACF(x);
varx = var(x);  %lag 0 term
ac1 = ac(1);   %lag 1 term
ac2 = ac(2);   %lag 2 term
ac3 = ac(3);   %lag 3 term
Gamma = [1 ac1 ac2; ac1 1 ac1; ac2 ac1 1]; %Y-W matrix for autocorr
gamma = [ac1 ac2 ac3];                     %rhs for Y-W
phi = Gamma\gamma';
disp(phi);
sigma2_w = varx*(1-[ac1 ac2 ac3]*phi);
plot(x);