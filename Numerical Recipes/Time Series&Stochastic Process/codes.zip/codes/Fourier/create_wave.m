function [ X ] = create_wave( n, A, B, fa, fb )
% creates a linear combingation of pure waves of sampling period 1s and
% specified frequencies, amplitudes, and total number of samples.
% n: number of sample points
% A vector of amplitudes for cosine terms
% B vector of amplitudes for sine terms
% fa vector of frequencies of cosine terms
% fb vector of frequencies for sin terms
t = linspace(0,1,n);   % 1 second sampling period

if (~isequal(length(A),length(B),length(fa),length(fb)))
    error('A and B must be same length; zero pad if necessary');
else
    m = length(A);
end

X = zeros(1,n);
for i=1:m
    X = X + A(i)*cos(2*pi*fa(i)*t) + B(i)*sin(2*pi*fb(i)*t);
end
X = X + 100*rand(1,n);
end