function [ ftilde ] = filter_convol( f, m )
% Applies even weight filter of size m to a time series f 
% using discrete convolution
% f: input signal 
% m: filter width, assumes uniform weights

%number of samples in signal
n = length(f);

% create filter weights, fill in all zeros
g = [ones(1,m)/m zeros(1,n-m)];
%note that convol only requires non-zero weights
ftilde = conv(f,g(1:m),'valid');


end

