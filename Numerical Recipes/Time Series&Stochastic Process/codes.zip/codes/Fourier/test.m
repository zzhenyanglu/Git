n = 100;
t = linspace(0,1,n)';
omega = 5;
A = randn();
B = randn();
f = A*sin(2*pi*omega*t) + B*cos(2*pi*omega*t) ;

figure(1); plot(2*real(fft(f))/n);
figure(2); plot(f);