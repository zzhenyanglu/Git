close all;
x = load('../../datasets/rec_series.txt');
n = numel(x);
omega = linspace(0,6,(n+1)/2);
figure(1);plot(x);
P1 = sqrt(n)/2*abs(2*fft(x)/n).^2;
P1 = P1(1:(n+1)/2);
figure(2);plot(omega,P1);
%center data
x = x - mean(x);
P2 = sqrt(n)/2*abs(2*fft(x)/n).^2;
P2 = P2(1:(n+1)/2);
figure(3); plot(omega,P2);
% zero pad up to next highest composite number -- 480 in this case
pad = 480-n;
x = [x ; zeros(pad,1)];
n = numel(x);
omega = linspace(0,6,n/2);
P3 = sqrt(n)/2*abs(2*fft(x)/n).^2;
P3 = P3(1:n/2);
figure(4);
plot(omega, P3);
