function [ ftilde ] = filter_fft( f, m )
% Applies even weight filter of size m to a time series f using FFT
% f: input signal 
% m: filter width, assumes uniform weights

%number of samples in signal
n = length(f);

% create filter weights, fill in all zeros
g = [ones(1,m)/m zeros(1,n-m)];

sf = size(f);
sg = size(g);
if (sf(1) ~= sg(1) || sf(2) ~= sg(2))
    error('input must be row vector');
end

%fourier transform of signal
fhat = fft(f); 
%fourier transform of filter
ghat = fft(g);

%apply filter in fourier space
tmp = fhat.*conj(ghat);  

%convert back to time domain
ftilde = ifft(tmp);

end


