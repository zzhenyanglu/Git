function [ psd ] = power_spec( X )
%Computes one-sided power spectrum
%   Detailed explanation goes here
% note if even number of points in X then coefficients are
% arranged as
% even n
% X(1): DC component
% X(2) = X(end)*, X(3) = X(end-1)*, X(m) = X(end-m+1), X=2...n/2
% X(n/2+1) is unique
% odd n
% X(1): DC component
% X(2) = X(end)*, X(3) = X(end-1)*, X(m) = X(end-m+1) , X=2...(n-1)/2 + 1
% no unique final point
n = length(X);
if (mod(n,2) == 0) 
    even = true;
else
    even = false;
end

Y = fft(X);
tmp = abs(Y)/n;
psd(1) = tmp(1);
if (even)
    psd(2:n/2) = 2*tmp(2:n/2);
else
    psd(2:(n-1)/2+1) = tmp(2:(n-1)/2+1);
end
end

