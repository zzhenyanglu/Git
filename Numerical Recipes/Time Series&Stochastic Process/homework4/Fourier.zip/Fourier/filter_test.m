% Compare filter_convol and filter_fft
%
%
P = '../codes/ARMA';
path(genpath(P),path);
n = 100;
f = ARp(n,[.1 .2]);
f = f';

ftilde1 = filter_fft(f,10);
ftilde2 = filter_convol(f,10);

plot(ftilde1);
hold on;
plot(ftilde2+2,'r');


