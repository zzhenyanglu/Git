#include <cstring>

//********************************************************************
//  Book.h
//
//  Represents a single book.
//*******************************************************************

class Book {

   public:
      Book (char *newTitle) {
         strcpy( title, newTitle );
      }

      char *getBook() {
         return title;
      }
      
   private:
      char title[81];

   };

