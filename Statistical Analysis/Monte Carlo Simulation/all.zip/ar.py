import random
from numeric import *

(a,b) = (0,2)

def p(x):
    return 3.0/8*x**2

c = 3.0/2

def accept_reject(p,a,b,c):
    while True:
        x = random.uniform(a,b)
        y = random.random()
        if y<p(x)/c: return x

data = []
for k in range(100000):
    data.append(accept_reject(p,a,b,c))

draw(histsets=[dict(data=data)],filename='x2.png')

