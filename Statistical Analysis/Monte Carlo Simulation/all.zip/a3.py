from numeric import *

class Shipping(MCEngine):
    def simulate_once(self):
        history = []
        t = 0.0
        loss = 0.0
        while True:
            t = t+random.expovariate(self.lamb)
            if t>self.days:
                break
            if random.random()<self.loss_prob:
                loss += self.xm*random.paretovariate(self.alpha)
                history.append((t,loss))
        self.histories.append(history)
        print loss
        return loss

s = Shipping()
s.lamb = 100 # packages/day
s.days = 250 # days to simulate
s.xm = 200.0
s.alpha = 3.0
s.loss_prob = 0.02

# results = [s.simulate_once() for i in range(200)]
N =200
s.histories = []
s.simulate_many(0,0,ns=N)
s.results.sort()


data=[(x,y) for x,y in enumerate(s.results)]
draw(linesets=[dict(data=data)],filename='a4.png')
draw(linesets=[dict(data=history) for history in s.histories[:20]],filename='a4history.png')

print s.results[int(N*0.97)+1]
