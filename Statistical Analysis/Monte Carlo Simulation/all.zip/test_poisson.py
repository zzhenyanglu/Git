import random
from numeric import draw
exponential = random.expovariate

def poisson(t = 0, 
      lamb = 24, # one per hour
      max_time = 1.0): # days
    n = 0
    t = 0.0
    while t<=max_time:        
        t += exponential(lamb)
        n+=1
    return n

data = []
for i in range(10000):
    data.append(poisson())

draw(histsets=[dict(data=data)],filename='poisson2.png')
