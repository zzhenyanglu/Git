from numeric import *
from math import *

def get_stock_history(name):
    storage = PersistentDictionary(path='test.sqlite')
    if name in storage:
        h = storage[name]
    else:
        aapl = YStock(name)
        h = aapl.historical()
        storage[name] = h
    v = [day['log_return'] for day in h[1:]]
    mu = sum(v)/len(v)
    variance = sum(x**2 for x in v)/len(v)-mu**2
    sigma = sqrt(variance)
    return [(day['date'].isoformat(),day['log_return']) for day in h[1:]]

def filter():
    amd_raw = get_stock_history('amd')
    intc_raw = get_stock_history('intc')
    
    amd = dict(amd_raw)
    intc = dict(intc_raw)
    
    amd_days = set(amd.keys())
    intc_days = set(intc.keys())
    common_days = amd_days.intersection(intc_days)
    
    print len(amd)
    print len(intc)
    
    amd = [r for (d,r) in amd_raw if d in common_days]
    intc = [r for (d,r) in intc_raw if d in common_days]
    print len(amd)
    print len(intc)
    mu_amd = sum(amd)/len(amd)
    mu_intc = sum(intc)/len(intc)
    var_amd = sum(x*x for x in amd)/len(amd)-mu_amd**2
    var_intc = sum(x*x for x in intc)/len(intc)-mu_intc**2
    sigma_amd = sqrt(var_amd)
    sigma_intc = sqrt(var_intc)
    cov = sum(amd[i]*intc[i] for i in range(len(amd)))/len(amd)-mu_amd*mu_intc
    corr = cov/sigma_amd/sigma_intc
    table = [(amd[i],intc[i]) for i in range(len(amd))]
    return table, mu_amd, mu_intc, var_amd, var_intc, cov

class OptionPricer(MCEngine):
    def simulate_once(self):
        S1 = self.S1
        S2 = self.S2
        L = self.L
        mu = self.mu
        N = self.option_expiration
        for day in range(N):
            u = Matrix.from_list([[random.gauss(0,1)],[random.gauss(0,1)]])
            r = L*u+mu
            S1 = S1*exp(r[0,0])
            S2 = S2*exp(r[1,0])
        ret = self.payoff(S1,S2)*exp(-self.rf/250*N)
        print ret
        return ret

    def payoff(self,S1,S2):
        return max(4.0*S1-S2,0)

pricer = OptionPricer()
table, mu_amd, mu_intc, var_amd, var_intc, cov = filter()

mu = Matrix.from_list([[mu_amd], [mu_intc]])
C = Matrix.from_list([[var_amd, cov],[cov, var_intc]])
L =  Cholesky(C)

pricer.mu = mu
pricer.L = L
pricer.S1 = 6.6
pricer.S2 = 26.88

pricer.rf = 0.03
pricer.option_expiration = 90

print pricer.simulate_many(0.01,0.01,1000)
