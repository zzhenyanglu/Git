import random

def make_data(n=100):
    table = []
    for k in range(n):
        a= random.uniform(0,2)
        b = random.uniform(1,3)
        table.append((a,b,a+b))
    return table

X=0
Y=1
Z=2

table = make_data(10000)
mu_X = sum(row[X] for row in table)/len(table) 
mu_Y = sum(row[Y] for row in table)/len(table) 
mu_Z = sum(row[Z] for row in table)/len(table) 
cov_XY = sum((row[X]-mu_X)*(row[Y]-mu_Y) for row in table)/len(table)
cov_YZ = sum((row[Y]-mu_Y)*(row[Z]-mu_Z) for row in table)/len(table)
cov_XZ = sum((row[X]-mu_X)*(row[Z]-mu_Z) for row in table)/len(table)

print mu_X, mu_Y, mu_Z
print cov_XY, cov_YZ, cov_XZ
