from numeric import *
from math import *

storage = PersistentDictionary(path='test.sqlite')
if 'aapl' in storage:
    h = storage['aapl']
else:
    aapl = YStock('AAPL')
    h = aapl.historical()
    storage['aapl'] = h

R = [day['log_return'] for day in h[1:]]
draw(histsets=[dict(data=R)], filename='aapl_hist.png')
print min(R), max(R)

###jump diffusion assumption
minjump = -0.20
jumps = [r for r in R if r<minjump]
mean_jump = sum(jumps)/len(jumps)
alpha = mean_jump/(mean_jump-minjump)
xm = minjump
lamb = float(len(jumps))/len(R)
nojumps = [r for r in R if r>=minjump]

mu = sum(nojumps)/len(nojumps)
variance = sum(x**2 for x in nojumps)/len(nojumps)-mu**2
sigma = sqrt(variance)

print 'lamb=',lamb
print 'xm=',xm
print 'alpha=',alpha
print 'mu=',mu
print 'sigma=',sigma

class OptionPricer(MCEngine):
    def simulate_once(self):
        rf =  self.risk_free_rate
        N = self.option['expiration']
        S = self.S_today
        name = self.model['name']
        mu = self.model['mu']
        sigma = self.model['sigma']
        history = []
        next_jump_time = random.expovariate(self.model['lamb'])
        for i in range(N):
            if name == 'gaussian':
                r = random.gauss(mu,sigma)
            elif name == 'resample':
                r = random.choice(self.historical_log_returns)
            elif name == 'jump-diffusion':
                if i>next_jump_time:
                    r = self.model['xm']*random.paretovariate(self.model['alpha'])
                    next_jump_time += random.expovariate(self.model['lamb'])
                else:
                    r = random.gauss(mu,sigma)
            S = S*exp(r)
            history.append(S)
        # S = S*exp(random.gauss(mu*N,sigma*sqrt(N)))
        return self.payoff(history)*exp(-rf/250*N)

    def payoff(self,history):
        raise NotImplemented

class EuropeanCallPricer(OptionPricer):
    def payoff(self,history):
        S = history[-1]
        F = self.option['strike']
        return max(S-F,0)

class EuropeanPutPricer(OptionPricer):
    def payoff(self,history):
        S = history[-1]
        F = self.option['strike']
        return max(F-S,0)

class DigitalBarrierPricer(OptionPricer):
    def payoff(self,history):
        F = self.option['barrier']
        for S in history:
            if S>F: return 1.0
        return 0.0

class AsianCallPricer(OptionPricer):
    def payoff(self,history):
        n = self.option['time_window']
        S = sum(history[-n:])/n
        F = self.option['strike']
        return max(S-F,0)


pricer = EuropeanCallPricer()

pricer.S_today = 568.18
pricer.risk_free_rate = 0.03
pricer.historical_log_returns = R

pricer.model = {} 
pricer.model['name'] = 'jump-diffusion' # daily
pricer.model['lamb'] = mu # daily
pricer.model['xm'] = xm
pricer.model['alpha'] = alpha
pricer.model['mu'] = mu # daily
pricer.model['sigma'] = sigma # daily

pricer.option = {}
pricer.option['expiration'] = 90
pricer.option['strike'] = 700.0
print pricer.simulate_many(ap=0.01,rp=0.01,ns=10000) 
