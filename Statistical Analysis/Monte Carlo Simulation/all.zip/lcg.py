from numeric import *
import time
class LCG(object):
    def __init__(self,seed,a=7**5,c=0,m=2**31-1):
        self.x=seed
        self.a=a
        self.c=c
        self.m = m
    def random(self):
        self.x = (self.a*self.x + self.c) % self.m
        return float(self.x)/self.m

randu = LCG(time.time())
x = randu.random()
table = []
for i in range(10000):
    y = x
    x = randu.random()
    table.append((x,y))

draw(ellisets=[dict(data=table)],filename='randu.png')
