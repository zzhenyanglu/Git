import random

def make_deck():
    deck=[]
    for i in range(26):
        deck.append('red')        
        deck.append('black')
    random.shuffle(deck)
    return deck

deck = make_deck()
print deck.pop()
print deck.pop()
print deck.pop()


