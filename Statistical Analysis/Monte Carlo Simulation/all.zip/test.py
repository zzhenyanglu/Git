import random
from numeric import draw

def pareto(xm,alpha):
    u = random.random()
    return xm*(u**(-1.0/alpha))

# we choose to measure time in days
T = 365 # days
lamb = 100.0 # losses/day
alpha = 2.0
xm = 3000 # mean loss = $6000


def simulate_once():
    t = 0
    n = 0
    while t<1.0:
        t = t + random.expovariate(6)
        n = n +1
    return n

def simulate_many(ap=10,rp=0.01,ns=1000):
    s = 0.0
    s2 = 0.0
    for n in range(1,ns):
        X = simulate_once()
        s += X
        s2 += X*X
        mu = s/n # E[X]
        variance = s2/n - mu**2 # E[X^2] - E[X]**2
        sigma = variance**0.5
        dmu = sigma/(n**0.5)
        if n>1000 and dmu<max(ap,rp*abs(mu)):
            return mu, dmu
    raise ArithmeticError, "No convergence"

mu, dmu = simulate_many(rp=0.05,ns=1000000)
print mu, dmu
