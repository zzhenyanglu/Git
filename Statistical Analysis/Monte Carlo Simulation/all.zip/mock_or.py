import random

def pareto(xm,mean):
    alpha = mean/(mean-xm)
    u = random.random()
    return xm*(u)**(-1.0/alpha)

def dt(ev_day):
    return random.expovariate(ev_day)

xm = 1000.0
mean = 9123.0
ev_day = 154.0 
days = 90.0
t = 0.0
data = []
while t<days:
    t += dt(ev_day)
    if t%7>5: t+=2
    a = pareto(xm,mean)
    data.append((t,a,0))

f = open('op_risk.csv','w')
for item in data: f.write('%i, %i\n' % (int(item[0]),int(item[1])))
f.close()


print len(data)/154
print sum(x[1]  for x in data)/len(data)

from numeric import *
draw(pointsets=[dict(data=data)],filename='op_risk.png')
