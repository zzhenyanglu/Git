from numeric import *
from math import sqrt, exp, log
import random
import copy

class Annealing(object):
    def E(self,x):
        raise NotImplementedError

    def domain(self):
        raise NotImplementedError

    def shift(self,x):
        raise NotImplementedError

    def minimize(self,T,n=1000,x=None):
        x = x or self.domain()
        minE = self.E(x)
        minx = copy.copy(x)
        oldE = minE
        for k in range(n):            
            y = self.shift(x)
            newE = self.E(y)
            if -T*log(random.random())>newE-oldE:
                x = y
                oldE = newE
                if newE<minE:
                    minE=newE
                    minx=copy.copy(x)
                    print newE, x                
        return minE, minx

class MyAnnealing(Annealing):
    def E(self,x):
        """ check different pixels """
        nr = len(self.image)
        nc = len(self.image[0])
        total = 0
        for r in range(nr):
            for c in range(nc):
                if self.image[r][c]==0: # white
                    for rec in x:
                        if rec[0]<=r<rec[0]+rec[2] and rec[1]<=c<rec[1]+rec[3]:
                            total+=1
                            break
                else: # black
                    total+=1
                    for rec in x:
                        if rec[0]<=r<rec[0]+rec[2] and rec[1]<=c<rec[1]+rec[3]:
                            total-=1
                            break
        return total

    def domain(self):
        return []

    def shift(self,x):
        x = copy.copy(x)
        nr = len(self.image)
        nc = len(self.image[0])
        """ add, reshape, delete rectangle """
        if len(x):
            k = random.randint(0,2)
        else:
            k = 0
        if k==0:            
            r = random.randint(0,nr-2)
            c = random.randint(0,nc-2)
            dr = random.randint(2,nr-r)
            dc = random.randint(2,nc-c)
            #print 'adding',(r,c,dr,dc)
            x.append((r,c,dr,dc))
            i = len(x)-1
        elif k==1:
            i = random.randint(0,len(x)-1)
            r = random.randint(0,nr-2)
            c = random.randint(0,nc-2)
            dr = random.randint(2,nr-r)
            dc = random.randint(2,nc-c)
            #print 'resizing',x[i]
            x[i]=(r,c,dr,dc)
        elif k==2:
            i = random.randint(0,len(x)-1)
            #print 'deleting',x[i]
            del x[i]        
        if k<2:
            for j in range(len(x)):
                if i!=j:
                    if contained(x[i],x[j]):
                        del x[i]
                        break
                    if contained(x[j],x[i]):
                        del x[j]
                        break
        return x

def contained(a,b):
    return (b[0]<=a[0] and b[1]<=a[1] and \
                a[0]+a[2]<=b[0]+b[2] and a[1]+a[3]<=b[1]+b[3])

def display(image):
    for row in image:
        print ''.join(('X' if e else ' ') for e in row)
            

m = MyAnnealing()
m.image = [
    [0,1,1,0,0],
    [0,1,1,0,0],
    [0,1,1,0,0],
    [0,1,1,0,0],
    [0,1,1,0,0]]

# expected output x = [(1,1,2,2),(3,3,2,2)]

display(m.image)
x = None
T = 10.0
for k in range(100):
    minE, x = m.minimize(T=T,n=1000,x=x)
    print minE, x
    T = T/2
