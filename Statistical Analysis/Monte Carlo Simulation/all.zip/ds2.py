import random


class DisjointSets(object):
    def __init__(self,n):
        self.clusters = [-1]*n

    def parent(self,i):
        while self.clusters[i]>=0:
            i = self.clusters[i]
        return i

    def join(self,i,j):
        pi = self.parent(i)
        pj = self.parent(j)
        if pi!=pj:
            self.clusters[pj]=pi

    def connected(self,i,j):
        return self.parent(i)==self.parent(j)


n = 1000
ds = DisjointSets(n)
for k in range(10000):
    i = random.randint(0,n-1)
    j = random.randint(0,n-1)
    ds.join(i,j)
print ds.connected(3,800)    
