from numeric import *
from math import sqrt
import random
import copy

class Metropolis(object):
    def p(self,x):
        raise NotImplementedError

    def domain(self,x):
        raise NotImplementedError

    def shift(self,x):
        raise NotImplementedError

    def random(self,m=10):
        x = self.domain(None)
        while True:
            for k in range(m):
                y = self.shift(x)
                a = self.p(y)/self.p(x)
                if random.random()<a:
                    x = y
            yield x

class MyMetropolis(Metropolis):
    def p(self,x):
        return (x[0]-x[1])**2

    def domain(self,x):
        return [random.uniform(-1,1),random.uniform(-1,1)]

    def shift(self,x):
        y = copy.copy(x)
        i = random.randint(0,len(y)-1)
        #while True:
        #    yi = y[i] + random.gauss(0,0.001)
        #    if -1<yi<+1: break
        y[i]=random.uniform(-1,1)
        return y

k = 0
data = []
for x in MyMetropolis().random(m=1):
    data.append(x)
    k += 1
    if k==100: break
"""
mu0 = sum(x[0] for x in data)/len(data)
mu1 = sum(x[1] for x in data)/len(data)
sigma0 = sqrt(sum(x[0]**2 for x in data)/len(data)-mu0**2)
sigma1 = sqrt(sum(x[1]**2 for x in data)/len(data)-mu1**2)
cov = sum(x[0]*x[1] for x in data)/len(data)-mu0*mu1
cor = cov/sigma0/sigma1

print 'mu0=',mu0
print 'mu1=',mu1
print 'sigma0=',sigma0
print 'sigma1=',sigma1
print 'corr=',cor
"""

draw(linesets=[dict(data=data)],filename="metropolis")
