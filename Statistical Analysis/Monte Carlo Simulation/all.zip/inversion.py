import random
from math import log
from numeric import *
def pareto(xm,alpha):
    u = random.random()
    return xm*(u**(-1.0/alpha))

data = []
for k in range(100000):
    x=pareto(100.0,2.0)
    if x<500: data.append(x)

draw(histsets=[dict(data=data)],filename='pareto.png')

