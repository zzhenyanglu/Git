from numeric import *
from mcengine import MCEngine

def pareto(xm,alpha):
    return float(xm)*(1.-random.random())**(-1.0/alpha)

#### READ THE DATA
lines = [x.strip() for x in open('op_risk.csv','r').readlines() if x.strip()]
items = [line.split(',') for line in lines]
items = [(float(item[0]),float(item[1]),0) for item in items]

#### COMPUTE time PARAMETERS
times = [item[0] for item in items]
#draw(histsets=[dict(data=times)],filename='op_risk_time.png')
times = [t - (t//7)*2 for t in times]
lamb = float(len(times))/max(times)

#### compute amount PARAMETERS
amounts = [item[1] for item in items if item[1]]
#draw(histsets=[dict(data=amounts)],filename='op_risk_amount.png')
xm = min(amounts)
mean = sum(amounts)/len(amounts)

#### ALGORITHMS
class SimulateOperationalRisk(MCEngine):
    def simulate_once(self):
        # days, losses_per_day, min_loss, mean_loss
        lamb = float(self.losses_per_day)
        xm = self.min_loss
        alpha = self.mean_loss/(self.mean_loss-self.min_loss)
        t = 0.0
        total_loss = 0.0
        while True:
            t = t+random.expovariate(lamb)
            if t>self.days: break
            # loss = pareto(xm,alpha) ## pareto model
            loss = random.choice(amounts) ## resampling
            total_loss += loss
        return total_loss

## CALL IL
s = SimulateOperationalRisk()
s.days = 52*5
s.losses_per_day =lamb
s.min_loss = min(amounts)
s.mean_loss = sum(amounts)/len(amounts)
s.simulate_many(ap=0,rp=0,ns=100)
print s.var(0.68)
