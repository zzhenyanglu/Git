import random

def biased_coin():
    u = random.random()
    if u<0.7: return 'head'
    else: return 'tail'

for i in range(100):
    print biased_coin()
