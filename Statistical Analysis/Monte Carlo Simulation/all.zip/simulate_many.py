def simulate_many(ap=10,rp=0.01,ns=1000):
    s = 0.0
    s2 = 0.0
    for n in range(1,ns):
        X = simulate_once()
        s += X
        s2 += X*X
        mu = s/n # E[X]
        variance = s2/n - mu**2 # E[X^2] - E[X]**2
        sigma = variance**0.5
        dmu = sigma/(n**0.5)
        if n>1000 and dmu<max(ap,rp*abs(mu)):
            return mu, dmu
    raise ArithmeticError, "No convergence"

