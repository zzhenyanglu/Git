from math import exp
def principal(A,n_years,apr=0.05):
    alpha = exp(-apr/12)
    return A*(alpha-1)/alpha/(alpha**(n_years*12)-1)

print principal(100000.0,10,apr=0.05)
