import random

def make_data(n=1000):
    table = []
    a = random.uniform(-1,1)
    for k in range(n):
        b = a
        a = random.uniform(-1,1)
        table.append((a,b))
    return table

A=0
B=1

table= make_data(1000000)
for row in table[:100]: print row
mu_A = sum(row[A] for row in table)/len(table)
mu_B = sum(row[B] for row in table)/len(table)
cov_AB = sum((row[A]-mu_A)*(row[B]-mu_B) for row in table)/len(table)
print mu_A, mu_B,cov_AB
