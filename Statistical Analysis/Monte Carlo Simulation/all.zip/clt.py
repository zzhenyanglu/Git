import random
from numeric import *

def make_data(n=100000):
    table = []
    for k in range(n):
        x = random.uniform(-1,1)
        x += random.uniform(-1,1)
        x += random.uniform(-1,1)
        x += random.uniform(-1,1)
        x += random.uniform(-1,1)
        x += random.uniform(-1,1)
        x += random.uniform(-1,1)
        table.append(x)
    return table

table=make_data()
draw(histsets=[dict(data=table)],xlab='x',ylab='frequency',filename='clt1.png')



    
