import random
from numeric import draw

def simulate_one(N):

    mu = 976
    sigma = 352
    buy_in_stock = 0.05
    buy_out_stock = 0.02
    price = 100.0
    cost = 30.0

    loss = N*cost
    profit = 0
    number_of_visitors = int(random.gauss(mu,sigma))
    for i in range(number_of_visitors):
        if N>0:
            if random.random()<buy_in_stock:
                profit+=100
                N = N-1
        else:
            if random.random()<buy_out_stock:
                profit+=100
    return profit-loss

def simulate_many(N,ap=10,rp=0.01,ns=1000):
    s = 0.0
    s2 = 0.0
    for n in range(1,ns):
        X = simulate_one(N)
        s += X
        s2 += X*X
        mu = s/n # E[X]
        variance = s2/n - mu**2 # E[X^2] - E[X]**2
        sigma = variance**0.5
        dmu = sigma/(n**0.5)
        if n>10 and dmu<max(ap,rp*abs(mu)):
            return mu
    raise ArithmeticError, "No convergence"

points = []
for N in range(10,100):
    mu = simulate_many(N,rp=0.01,ns=10000)
    print N, mu
    points.append((N,mu))

draw(linesets=[dict(data=points)],xlab='N',filename='mechant_100.png')
