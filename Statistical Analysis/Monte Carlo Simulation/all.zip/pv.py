from math import *

class SimpleTransaction(object):
    def __init__(self,A,t,p=1.0):
        self.A = float(A)
        self.t = float(t)
        self.p = float(p)
    def present_value(self,r):
        return self.A*exp(-r*self.t)*self.p

class ComplexTransaction(list):
    def present_value(self,r):
        return sum(item.present_value(r) for item in self)

c = ComplexTransaction()
for i in range(12):
    c.append(SimpleTransaction(100,1.0/12*(i+1),0.9))
c.append(SimpleTransaction(300,2.0,0.7))
c.append(SimpleTransaction(500,2.0,0.3))
print c.present_value(0.035)
