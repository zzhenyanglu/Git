from numeric import *
from math import sqrt
import pickle
r = pickle.load(open('op_results.pickle','r'))

def resample(r,n):
    return [random.choice(r) for i in range(n)]

def old_way(r):
    mu = sum(r)/len(r)
    mu = sum(x for x in r)/len(r)
    # code from simulate many
    variance = sum(x*x for x in r)/len(r) - mu**2
    sigma = sqrt(variance)
    dmu = sigma/sqrt(len(r))
    return mu-dmu, mu, mu+dmu

def bootstrap(r,nboot=100):
    mu = sum(r)/len(r)

    # new
    mu_samples = []
    for i in range(nboot):
        sample = resample(r,len(r))
        mu_sample = sum(sample)/len(sample)
        mu_samples.append(mu_sample)
    draw(histsets=[dict(data=mu_samples)],filename='analysis_samples.png')
    mu_samples.sort()
    mu_minus = mu_samples[15]
    mu_plus = mu_samples[100-16]
    return mu_minus, mu,mu_plus

print bootstrap(r)
print old_way(r)
