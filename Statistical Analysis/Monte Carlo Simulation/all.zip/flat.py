import random
from numeric import draw

N=1000000

v = [0]*11
for i in range(N):
    x = int(5.5*(random.random()+random.random()))
    v[x]+=1

points=[(i,v[i]) for i in range(len(v))]
    
draw(linesets=[dict(data=points)],xlab='N',filename='binning.png')
