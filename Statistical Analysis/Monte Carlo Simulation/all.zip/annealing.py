from numeric import *
from math import sqrt, exp, log
import random
import copy

class Annealing(object):
    def E(self,x):
        raise NotImplementedError

    def domain(self):
        raise NotImplementedError

    def shift(self,x):
        raise NotImplementedError

    def minimize(self,T,n=1000,x=None):
        x = x or self.domain()
        minE = self.E(x)
        minx = copy.copy(x)
        oldE = minE
        for k in range(n):            
            y = self.shift(x)
            newE = self.E(y)
            if -T*log(random.random())>newE-oldE:
                x = y
                oldE = newE
                if newE<minE:
                    minE=newE
                    minx=copy.copy(x)
                    # print newE, x                
        return minE, minx

class MyAnnealing(Annealing):
    def E(self,x):
        return sum((x[i]-i)*(x[i]+i) for i in range(20))**2

    def domain(self):
        return [0.0]*20

    def shift(self,x):
        while True:
            j = random.randint(0,19)
            y = [x[i]+(random.gauss(0,0.1) if i==j else 0.0) \
                     for i in range(20)]
            return y

m = MyAnnealing()
x = None
T = 10.0
for k in range(100):
    minE, x = m.minimize(T=T,n=1000,x=x)
    print minE, x
    T = T/2
