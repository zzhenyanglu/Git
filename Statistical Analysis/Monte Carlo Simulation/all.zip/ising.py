import random
from math import exp, log


class Ising(object):
    def __init__(self,n):
        self.n = n
        self.x = [+1]*(n*n)
    def getx(self,r,c):
        return self.x[self.n*r+c]
    def setx(self,r,c,value):
        self.x[self.n*r+c] = value
    def pprint(self):
        for r in range(self.n):
            print ''.join(' ' if self.getx(r,c)<0 else 'x' for c in range(self.n))
    def E(self):
        total = 0
        for r in range(self.n):
            for c in range(self.n):
                if r>0:
                    total -= self.getx(r,c)*self.getx(r-1,c)
                if r<self.n-1:
                    total -= self.getx(r,c)*self.getx(r+1,c)
                if c>0:
                    total -= self.getx(r,c)*self.getx(r,c-1)
                if c<self.n-1:
                    total -= self.getx(r,c)*self.getx(r,c+1)
        return total

    def correction(self,r,c):
        total = 0.0
        if r>0:
            total -= self.getx(r,c)*self.getx(r-1,c)
        if r<self.n-1:
            total -= self.getx(r,c)*self.getx(r+1,c)
        if c>0:
            total -= self.getx(r,c)*self.getx(r,c-1)
        if c<self.n-1:
            total -= self.getx(r,c)*self.getx(r,c+1)
        return total*2


    def p(self):
        return exp(-1.0/self.t*self.E())

    def metropolis(self):
        results = []
        k =1
        while True:
            r = random.randint(0,self.n-1)
            c = random.randint(0,self.n-1)
            self.setx(r,c,-self.getx(r,c))
            # p_guess = self.p()
            dE = self.correction(r,c)
            if -self.t*log(random.random())>dE:
                pass
            else:
                # revert
                self.setx(r,c,-self.getx(r,c))
            self.pprint()
            y = float(sum(self.x))/len(self.x)
            results.append(y)
            print sum(results)/k
            k+=1

ising = Ising(10)
print ising.E()
ising.setx(2,4,-1)
print ising.E()
ising.t = 5.0
ising.metropolis()


