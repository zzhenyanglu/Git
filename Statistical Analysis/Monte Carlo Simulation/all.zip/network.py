import random
from numeric import *
from math import exp

class DisjointSets(object):
    def __init__(self,n):
        self.clusters = [-1]*n

    def parent(self,i):
        while self.clusters[i]>=0:
            i = self.clusters[i]
        return i

    def join(self,i,j):
        pi = self.parent(i)
        pj = self.parent(j)
        if pi!=pj:
            self.clusters[pj]=pi

    def connected(self,i,j):
        return self.parent(i)==self.parent(j)

class Network(MCEngine):
    def simulate_once(self):
        ds = DisjointSets(self.number_of_vertices)
        for link in self.links:
            (i,j,p) = link
            if random.random()>p:
                ds.join(i,j)
        return 1.0 if ds.connected(self.source,self.destination) else 0.0

network = Network()
n = 100
network.number_of_vertices = n
network.links = []
for k in range(n*3):
    i = random.randint(0,n-1)
    j = random.randint(0,n-1)
    network.links.append((i,j,0.7))
network.source = random.randint(0,n-1)
network.destination = random.randint(0,n-1)

mymap  = [(random.random(),random.random()) for i in range(n)]
draw(linesets=[dict(data=[mymap[i],mymap[j]]) for i,j,p in network.links],filename='clusters.png')

print network.simulate_many(ap=0.01,rp=0.01,ns=1000)

