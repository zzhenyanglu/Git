from numeric import *
from math import *

storage = PersistentDictionary(path='test.sqlite')
if 'aapl' in storage:
    h = storage['aapl']
else:
    aapl = YStock('AAPL')
    h = aapl.historical()
    storage['aapl'] = h

v = [day['log_return'] for day in h[1:]]
draw(histsets=[dict(data=v)], filename='aapl_hist.png')
print min(v), max(v)

### gaussian log return assumption
mu = sum(v)/len(v)
variance = sum(x**2 for x in v)/len(v)-mu**2
sigma = sqrt(variance)
print 'mu=',mu
print 'sigma=',sigma

class OptionPricer(MCEngine):
    def simulate_once(self):
        rf =  self.risk_free_rate
        N = self.option['expiration']
        S = self.S_today
        name = self.model['name']
        mu = self.model['mu']
        sigma = self.model['sigma']
        history = []
        for i in range(N):
            if name == 'gaussian':
                S = S*exp(random.gauss(mu,sigma))
            elif name == 'resample':
                S = S*exp(random.choice(self.historical_log_returns))
                
            history.append(S)
        # S = S*exp(random.gauss(mu*N,sigma*sqrt(N)))
        return self.payoff(history)*exp(-rf/250*N)

    def payoff(self,history):
        raise NotImplemented

class EuropeanCallPricer(OptionPricer):
    def payoff(self,history):
        S = history[-1]
        F = self.option['strike']
        return max(S-F,0)

class EuropeanPutPricer(OptionPricer):
    def payoff(self,history):
        S = history[-1]
        F = self.option['strike']
        return max(F-S,0)

class DigitalBarrierPricer(OptionPricer):
    def payoff(self,history):
        F = self.option['barrier']
        for S in history:
            if S>F: return 1.0
        return 0.0

class AsianCallPricer(OptionPricer):
    def payoff(self,history):
        n = self.option['time_window']
        S = sum(history[-n:])/n
        F = self.option['strike']
        return max(S-F,0)

pricer = EuropeanCallPricer()

pricer.S_today = 568.18
pricer.risk_free_rate = 0.03
pricer.historical_log_returns = v

pricer.model = {} 
pricer.model['name'] = 'gaussian' or 'resample' # daily
pricer.model['mu'] = mu # daily
pricer.model['sigma'] = sigma # daily

pricer.option = {}
pricer.option['expiration'] = 90
pricer.option['strike'] = 700.0

a=[]
b=[]
c=[]
d=[]
e=[]
N= 10
while N<=10000:
    mu_minus95, mu_minus68, mu, mu_plus68, mu_plus95 = pricer.simulate_many(ap=0.00,rp=0.00,ns=N) 
    print mu
    a.append((N,mu_minus95))
    b.append((N,mu_minus68))
    c.append((N,mu))
    d.append((N,mu_plus68))
    e.append((N,mu_plus95))
    N=2*N
draw(linesets=[dict(data=a),dict(data=b),dict(data=c),dict(data=d),dict(data=e)],
     filename='convergence.png')

