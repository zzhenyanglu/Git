from numeric import *

def get_stock_history(name):
    storage = PersistentDictionary(path='test.sqlite')
    if name in storage:
        h = storage[name]
    else:
        aapl = YStock(name)
        h = aapl.historical()
        storage[name] = h
    v = [day['log_return'] for day in h[1:]]
    mu = sum(v)/len(v)
    variance = sum(x**2 for x in v)/len(v)-mu**2
    sigma = sqrt(variance)
    return [(day['date'].isoformat(),day['log_return']) for day in h[1:]]

def test():
    amd_raw = get_stock_history('amd')
    intc_raw = get_stock_history('intc')
    
    amd = dict(amd_raw)
    intc = dict(intc_raw)
    
    amd_days = set(amd.keys())
    intc_days = set(intc.keys())
    common_days = amd_days.intersection(intc_days)
    
    print len(amd)
    print len(intc)
    
    amd = [r for (d,r) in amd_raw if d in common_days]
    intc = [r for (d,r) in intc_raw if d in common_days]
    print len(amd)
    print len(intc)
    mu_amd = sum(amd)/len(amd)
    mu_intc = sum(intc)/len(intc)
    var_amd = sum(x*x for x in amd)/len(amd)-mu_amd**2
    var_intc = sum(x*x for x in intc)/len(intc)-mu_intc**2
    sigma_amd = sqrt(var_amd)
    sigma_intc = sqrt(var_intc)
    cov = sum(amd[i]*intc[i] for i in range(len(amd)))/len(amd)-mu_amd*mu_intc
    corr = cov/sigma_amd/sigma_intc
    print corr
