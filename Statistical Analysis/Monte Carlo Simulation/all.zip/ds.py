n = 5
clusters = []
for k in range(n):
    clusters.append([k])


def join(i,j):
    for k in range(len(clusters)):
        cluster = clusters[k]
        if i in cluster:
            if j in cluster:
                return
            first_cluster = cluster
            del clusters[k]
            break
    for k in range(len(clusters)):
        cluster = clusters[k]
        if j in cluster:
            cluster += first_cluster
            break

def connected(i,j):
    for k in range(len(clusters)):
        cluster = clusters[k]
        if i in cluster and j in cluster:
            return True
    return False


print clusters
join(1,4)
print clusters
join(1,3)
print clusters
print connected(3,4)
