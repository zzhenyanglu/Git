import random
from math import *
from numeric import draw

class RandomSource(object):
    def random(self): 
        return random.random()
    def bernoulli(self,p):
        u = self.random()
        if u<p: return 1
        return 0
    def lookup(self,table = [0.20, 0.15, 0.07, 0.13, 0.20, 0.25],epsilon=1e-6):
        u = self.random()
        k =0 
        for p in table:
            if u<p+epsilon: return k
            else: u = u - p
            k += 1 
    def lookup2(self,table,epsilon=1e-6):
        a = [(p,i)  for i,p in enumerate(table)]
        a.sort()
        a.reverse()
        u = self.random()
        for p,k in a:
            if u<p+epsilon: return k
            else: u = u - p
    def binomial(self,n,p):
        u = self.random()
        prob = (1.0-p)**n
        for k in range(n+1):
            if u<=prob: return k
            else: u = u - prob
            prob = float(n-k)/(k+1)*p/(1.0-p)*prob
        return k
    def negative_binomial(self,k,p,epsilon=1e-6):
        u = self.random()
        prob = p**k
        n = k
        while True:
            if u<=prob: return k
            else: u = u - prob
            prob = float(n)/(n+1-k)*(1.0-p)*prob
            n = n+1
    def poisson(self,lamb,epsilon=1e-4):
        u = self.random()
        prob = exp(-lamb)
        k =0 
        while True:
            if u<=prob+epsilon: return k
            else: u = u - prob
            prob = float(lamb)/(k+1)*prob
            k+=1
    def accept_reject(self,p,a,b,max_p):
        while True:
            x = self.random()*(b-a)+a
            y = self.random()*max_p
            if y<p(x): return x


def p(x): return (1.0/110)*x**5
max_p = p(3)


g = RandomSource()
data = []
for k in range(10000):
    data.append(g.accept_reject(p,2,3,max_p=max_p))



draw(histsets=[dict(data=data)],filename='three_x_square.png')
    
