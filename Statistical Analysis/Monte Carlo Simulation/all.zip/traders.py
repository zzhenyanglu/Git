from numeric import *
import random

class Traders(MCEngine):
    def simulate_once(self):
        jumps = []
        t = 0
        while True:
            t = t+random.expovariate(self.lamb)
            if t>self.days: break
            jumps.append(int(t))
        total_capital = 0.0
        for trader in range(self.N):
            capital = self.A/self.N
            r = 0.0
            for t in jumps:
                r += random.paretovariate(self.alpha)*self.xm 
            d = self.days - len(jumps)
            r += random.gauss(self.mu*d,self.sigma*math.sqrt(d))
            #return r
            capital *= exp(r)
            total_capital += capital
        arithmetic_return = (total_capital-self.A)/self.A
        #return arithmetic_return
        return 0.01*max(total_capital-self.A,0)

traders = Traders()
traders.days = 250
traders.mu = 0.0005
traders.sigma = 0.04
traders.lamb = 1.0/(10*250)
traders.xm = -0.33
traders.alpha = 1.5
traders.A = 1e7
traders.N = 100
traders.simulate_many(ap=0.0,rp=0.0,ns=1000)
draw(histsets=[dict(data=traders.results)],filename='hist_100.png')
